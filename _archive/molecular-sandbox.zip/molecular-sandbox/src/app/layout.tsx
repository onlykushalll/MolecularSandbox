import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "The Molecular Sandbox — Scientifically Accurate Chemistry Simulator",
  description: "A photorealistic 3D chemistry simulator with real stoichiometry, thermodynamics, and physics. Experiment safely in a virtual lab.",
  keywords: ["chemistry", "simulator", "3D", "education", "stoichiometry", "science"],
  icons: { icon: "/favicon.svg" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#070b10",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        style={{ background: '#070b10', color: '#e2e8f0', overflow: 'hidden' }}
      >
        {children}
      </body>
    </html>
  );
}
