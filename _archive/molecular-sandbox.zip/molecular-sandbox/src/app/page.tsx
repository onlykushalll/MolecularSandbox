'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Main Application Page
// Full-screen 3D lab with floating glassmorphism panels
// ============================================================

import dynamic from 'next/dynamic';
import { Suspense, useEffect, useState } from 'react';
import { useLabStore } from '@/lib/store/lab-store';
import ChemicalPanel from '@/components/lab/ChemicalPanel';
import InstrumentPanel from '@/components/lab/InstrumentPanel';
import LabJournal from '@/components/lab/LabJournal';
import SafetyPanel from '@/components/lab/SafetyPanel';
import Toolbar from '@/components/lab/Toolbar';
import ReactionAlert from '@/components/lab/ReactionAlert';

const LabScene = dynamic(() => import('@/components/lab/LabScene'), {
  ssr: false,
  loading: () => <SceneLoader />,
});

function SceneLoader() {
  return (
    <div style={{
      position:'absolute',inset:0,display:'flex',flexDirection:'column',
      alignItems:'center',justifyContent:'center',background:'#070b10',gap:'20px',
    }}>
      <div style={{ fontSize:'52px', animation:'float 2s ease-in-out infinite' }}>⚗️</div>
      <div style={{ fontFamily:'"Space Mono",monospace',fontSize:'14px',color:'#22c55e',letterSpacing:'0.2em',fontWeight:700 }}>
        THE MOLECULAR SANDBOX
      </div>
      <div style={{ width:'200px',height:'2px',background:'rgba(255,255,255,0.06)',borderRadius:'1px',overflow:'hidden' }}>
        <div style={{ height:'100%',background:'linear-gradient(90deg,transparent,#22c55e,transparent)',animation:'shimmer 1.5s infinite',backgroundSize:'200% 100%' }} />
      </div>
      <div style={{ fontSize:'10px',color:'#334155',fontFamily:'"Space Mono",monospace',letterSpacing:'0.1em' }}>
        INITIALISING CHEMISTRY ENGINE...
      </div>
      <style>{`
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-12px)} }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
      `}</style>
    </div>
  );
}

function CanvasDragOverlay() {
  const { draggingChemical, containers, selectedContainerId, addChemicalToContainer } = useLabStore();
  if (!draggingChemical) return null;
  return (
    <div
      style={{ position:'absolute',inset:0,zIndex:10 }}
      onDragOver={e => e.preventDefault()}
      onDrop={e => {
        e.preventDefault();
        const formula = e.dataTransfer.getData('chemical');
        const target = selectedContainerId ?? containers[0]?.id;
        if (formula && target) {
          addChemicalToContainer(target, formula, 10);
          useLabStore.getState().setDraggingChemical(null);
        }
      }}
    />
  );
}

function KeyboardShortcuts() {
  const { setToolMode, togglePanel, selectedContainerId, updateContainer, containers } = useLabStore();
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === 'INPUT') return;
      switch (e.key.toLowerCase()) {
        case 's': setToolMode('select'); break;
        case 'p': setToolMode('pour'); break;
        case 'h': setToolMode('heat'); break;
        case 'r': setToolMode('stir'); break;
        case 'j': togglePanel('journal'); break;
        case 'i': togglePanel('instruments'); break;
        case 'c': togglePanel('chemicals'); break;
        case 'x': togglePanel('safety'); break;
        case 'f': {
          if (selectedContainerId) {
            const c = containers.find(c => c.id === selectedContainerId);
            if (c) updateContainer(c.id, { isHeating: !c.isHeating });
          }
          break;
        }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [selectedContainerId, containers, setToolMode, togglePanel, updateContainer]);
  return null;
}

function PPEGate() {
  const { isPPEComplete, equipPPE } = useLabStore();
  const [dismissed, setDismissed] = useState(false);
  if (isPPEComplete() || dismissed) return null;
  return (
    <div style={{
      position:'absolute',inset:0,background:'rgba(0,0,0,0.8)',backdropFilter:'blur(12px)',
      zIndex:100,display:'flex',alignItems:'center',justifyContent:'center',
    }}>
      <div style={{
        background:'rgba(10,14,20,0.98)',border:'1px solid rgba(251,191,36,0.3)',
        borderRadius:'20px',padding:'48px',maxWidth:'420px',textAlign:'center',
        boxShadow:'0 0 60px rgba(251,191,36,0.1), 0 0 0 1px rgba(255,255,255,0.04)',
      }}>
        <div style={{ fontSize:'48px',marginBottom:'20px' }}>🛡️</div>
        <div style={{
          fontFamily:'"Space Mono",monospace',fontSize:'15px',color:'#fbbf24',
          fontWeight:700,letterSpacing:'0.15em',marginBottom:'10px',
        }}>
          SAFETY PROTOCOL
        </div>
        <p style={{
          fontSize:'11px',color:'#475569',fontFamily:'"Space Mono",monospace',
          lineHeight:1.8,marginBottom:'28px',
        }}>
          Equip personal protective equipment<br />
          before entering the laboratory.
        </p>
        <div style={{ display:'flex',gap:'14px',justifyContent:'center',marginBottom:'20px' }}>
          {[
            { id:'goggles' as const, icon:'🥽', label:'Safety Goggles' },
            { id:'gloves' as const, icon:'🧤', label:'Nitrile Gloves' },
          ].map(item => (
            <button key={item.id} onClick={() => equipPPE(item.id)} style={{
              padding:'16px 20px',background:'rgba(34,197,94,0.08)',
              border:'2px solid rgba(34,197,94,0.25)',borderRadius:'12px',
              color:'#22c55e',cursor:'pointer',fontFamily:'"Space Mono",monospace',
              fontSize:'10px',display:'flex',flexDirection:'column',alignItems:'center',gap:'8px',
              letterSpacing:'0.05em',transition:'all 0.2s',
            }}>
              <span style={{ fontSize:'28px' }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>
        <button onClick={() => setDismissed(true)} style={{
          background:'transparent',border:'none',color:'#1e293b',
          fontSize:'9px',fontFamily:'"Space Mono",monospace',cursor:'pointer',letterSpacing:'0.05em',
        }}>
          Skip (demonstration mode)
        </button>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <div style={{ position:'fixed',inset:0,background:'#070b10',overflow:'hidden' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:rgba(34,197,94,0.2);border-radius:2px}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}
      `}</style>

      {/* 3D Canvas */}
      <div style={{ position:'absolute',top:'52px',left:0,right:0,bottom:'42px' }}>
        <Suspense fallback={<SceneLoader />}>
          <LabScene />
        </Suspense>
        <CanvasDragOverlay />
      </div>

      {/* UI panels */}
      <Toolbar />
      <ChemicalPanel />
      <InstrumentPanel />
      <LabJournal />
      <SafetyPanel />
      <ReactionAlert />
      <KeyboardShortcuts />
      <PPEGate />

      {/* Shortcut legend */}
      <div style={{
        position:'absolute',bottom:'48px',right:'244px',
        fontSize:'8px',color:'#1e293b',fontFamily:'"Space Mono",monospace',
        letterSpacing:'0.05em',padding:'4px 8px',zIndex:5,lineHeight:1.9,
      }}>
        [S]elect · [P]our · [H]eat · [J]ournal · [C]hemicals · [I]nstruments · [X] Safety
      </div>
    </div>
  );
}
