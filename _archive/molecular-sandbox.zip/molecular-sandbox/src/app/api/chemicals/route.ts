import { NextResponse } from 'next/server';
import { CHEMICALS } from '@/lib/chemistry/data';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get('category');
  const search = searchParams.get('search');

  let results = CHEMICALS;

  if (category && category !== 'all') {
    results = results.filter(c => c.category === category);
  }

  if (search) {
    const q = search.toLowerCase();
    results = results.filter(c =>
      c.name.toLowerCase().includes(q) ||
      c.formula.toLowerCase().includes(q) ||
      c.id.toLowerCase().includes(q)
    );
  }

  return NextResponse.json({
    chemicals: results,
    total: results.length,
  });
}
