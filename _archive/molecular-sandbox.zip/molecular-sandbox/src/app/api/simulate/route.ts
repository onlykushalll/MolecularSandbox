import { NextResponse } from 'next/server';
import { solveReaction } from '@/lib/chemistry/engine';
import type { ContainerState } from '@/lib/chemistry/types';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const container: ContainerState = body.container;

    if (!container) {
      return NextResponse.json({ error: 'container is required' }, { status: 400 });
    }

    const result = solveReaction(container);

    return NextResponse.json({
      result,
      timestamp: Date.now(),
    });
  } catch (err) {
    console.error('Simulate error:', err);
    return NextResponse.json({ error: 'Simulation failed' }, { status: 500 });
  }
}
