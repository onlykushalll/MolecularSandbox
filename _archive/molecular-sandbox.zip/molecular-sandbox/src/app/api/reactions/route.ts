import { NextResponse } from 'next/server';
import { REACTIONS } from '@/lib/chemistry/data';
import { findReaction } from '@/lib/chemistry/engine';
import type { MixtureComponent } from '@/lib/chemistry/types';

export async function GET() {
  return NextResponse.json({
    reactions: REACTIONS,
    total: REACTIONS.length,
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const contents: MixtureComponent[] = body.contents ?? [];

    const reaction = findReaction(contents);

    return NextResponse.json({
      found: !!reaction,
      reaction: reaction ?? null,
    });
  } catch {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 });
  }
}
