'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Safety & PPE Panel
// GHS symbols | Violation alerts | Fume hood status
// ============================================================

import { motion, AnimatePresence } from 'framer-motion';
import { useLabStore, type PPEItem } from '@/lib/store/lab-store';
import { CHEMICAL_MAP } from '@/lib/chemistry/data';
import type { GHSHazard } from '@/lib/chemistry/types';

const PPE_ITEMS: { id: PPEItem; name: string; icon: string; desc: string }[] = [
  { id: 'goggles', name: 'Safety Goggles', icon: '🥽', desc: 'Eye protection — required' },
  { id: 'gloves', name: 'Nitrile Gloves', icon: '🧤', desc: 'Hand protection — required' },
  { id: 'lab_coat', name: 'Lab Coat', icon: '🥼', desc: 'Body protection' },
  { id: 'face_shield', name: 'Face Shield', icon: '🛡️', desc: 'Full face protection' },
];

function PPEButton({ item }: { item: typeof PPE_ITEMS[number] }) {
  const { equippedPPE, equipPPE, removePPE } = useLabStore();
  const equipped = equippedPPE.has(item.id);
  const required = item.id === 'goggles' || item.id === 'gloves';

  return (
    <button
      onClick={() => equipped ? removePPE(item.id) : equipPPE(item.id)}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '4px',
        padding: '10px 8px',
        background: equipped
          ? 'rgba(34,197,94,0.15)'
          : 'rgba(255,255,255,0.03)',
        border: `2px solid ${equipped
          ? '#22c55e'
          : required ? 'rgba(251,191,36,0.4)' : 'rgba(255,255,255,0.08)'}`,
        borderRadius: '10px',
        cursor: 'pointer',
        flex: 1,
        transition: 'all 0.2s',
        position: 'relative',
      }}
    >
      {required && !equipped && (
        <span style={{
          position: 'absolute',
          top: '-5px',
          right: '-5px',
          background: '#fbbf24',
          color: '#000',
          borderRadius: '50%',
          width: '14px',
          height: '14px',
          fontSize: '8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontWeight: 700,
        }}>!</span>
      )}

      <span style={{ fontSize: '20px' }}>{item.icon}</span>
      <span style={{
        fontSize: '8px',
        fontFamily: '"Space Mono", monospace',
        color: equipped ? '#22c55e' : '#475569',
        textAlign: 'center',
        lineHeight: 1.3,
      }}>
        {item.name.split(' ').map((w, i) => <span key={i}>{w}<br /></span>)}
      </span>

      {equipped && (
        <span style={{
          fontSize: '7px',
          color: '#22c55e',
          fontFamily: '"Space Mono", monospace',
        }}>
          ✓ ON
        </span>
      )}
    </button>
  );
}

function HazardBadge({ hazard }: { hazard: GHSHazard }) {
  const color = hazard.signal === 'Danger' ? '#f87171' : '#fbbf24';

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      padding: '4px 8px',
      background: `${color}0a`,
      border: `1px solid ${color}22`,
      borderRadius: '5px',
      marginBottom: '3px',
    }}>
      <span style={{ fontSize: '12px' }}>{hazard.symbol}</span>
      <div>
        <div style={{
          fontSize: '8px',
          color,
          fontFamily: '"Space Mono", monospace',
          fontWeight: 700,
        }}>
          {hazard.signal}: {hazard.code}
        </div>
        <div style={{ fontSize: '8px', color: '#475569' }}>{hazard.category}</div>
      </div>
    </div>
  );
}

export default function SafetyPanel() {
  const {
    isPanelOpen, togglePanel,
    equippedPPE, isPPEComplete,
    isInsideFumeHood, setInsideFumeHood,
    safetyViolations,
    containers, selectedContainerId,
  } = useLabStore();

  const isOpen = isPanelOpen['safety'];
  const fullPPE = isPPEComplete();

  // Collect all hazards from contents in all containers
  const allHazards: GHSHazard[] = [];
  containers.forEach(c => {
    c.contents.forEach(comp => {
      const chem = CHEMICAL_MAP.get(comp.formula);
      chem?.hazards.forEach(h => {
        if (!allHazards.find(x => x.code === h.code)) {
          allHazards.push(h);
        }
      });
    });
  });

  return (
    <>
      {/* Safety status bar at bottom */}
      <div style={{
        position: 'absolute',
        bottom: 0,
        left: '260px',
        right: '240px',
        height: '42px',
        background: 'rgba(8,12,18,0.92)',
        backdropFilter: 'blur(16px)',
        borderTop: '1px solid rgba(255,255,255,0.06)',
        display: 'flex',
        alignItems: 'center',
        padding: '0 16px',
        gap: '16px',
        zIndex: 15,
      }}>
        {/* PPE status */}
        <div
          onClick={() => togglePanel('safety')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            cursor: 'pointer',
          }}
        >
          <div style={{
            width: '8px', height: '8px', borderRadius: '50%',
            background: fullPPE ? '#22c55e' : '#fbbf24',
            boxShadow: `0 0 6px ${fullPPE ? '#22c55e' : '#fbbf24'}`,
          }} />
          <span style={{
            fontFamily: '"Space Mono", monospace',
            fontSize: '10px',
            color: fullPPE ? '#22c55e' : '#fbbf24',
          }}>
            {fullPPE ? '✓ PPE OK' : '⚠ PPE REQUIRED'}
          </span>
        </div>

        {/* PPE icons */}
        <div style={{ display: 'flex', gap: '4px' }}>
          {PPE_ITEMS.map(item => (
            <span
              key={item.id}
              title={item.name}
              style={{
                fontSize: '14px',
                opacity: equippedPPE.has(item.id) ? 1 : 0.2,
                filter: equippedPPE.has(item.id) ? 'none' : 'grayscale(1)',
              }}
            >
              {item.icon}
            </span>
          ))}
        </div>

        {/* Fume hood toggle */}
        <button
          onClick={() => setInsideFumeHood(!isInsideFumeHood)}
          style={{
            fontSize: '9px',
            fontFamily: '"Space Mono", monospace',
            padding: '4px 10px',
            borderRadius: '4px',
            border: `1px solid ${isInsideFumeHood ? '#22c55e44' : 'rgba(255,255,255,0.1)'}`,
            background: isInsideFumeHood ? 'rgba(34,197,94,0.12)' : 'transparent',
            color: isInsideFumeHood ? '#22c55e' : '#475569',
            cursor: 'pointer',
          }}
        >
          {isInsideFumeHood ? '🔄 FUME HOOD: ON' : '🔄 FUME HOOD: OFF'}
        </button>

        {/* Active hazards */}
        {allHazards.length > 0 && (
          <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
            {allHazards.slice(0, 4).map(h => (
              <span key={h.code} title={`${h.signal}: ${h.category}`} style={{ fontSize: '13px' }}>
                {h.symbol}
              </span>
            ))}
            {allHazards.length > 4 && (
              <span style={{ fontSize: '9px', color: '#475569' }}>
                +{allHazards.length - 4}
              </span>
            )}
          </div>
        )}

        {/* Violations */}
        <AnimatePresence>
          {safetyViolations.length > 0 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              style={{
                marginLeft: 'auto',
                fontSize: '9px',
                color: '#f87171',
                fontFamily: '"Space Mono", monospace',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
              }}
            >
              🚨 {safetyViolations[safetyViolations.length - 1]}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Safety panel drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', stiffness: 350, damping: 35 }}
            style={{
              position: 'absolute',
              bottom: '42px',
              left: '260px',
              right: '240px',
              background: 'rgba(8,12,18,0.96)',
              backdropFilter: 'blur(20px)',
              borderTop: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '16px 16px 0 0',
              padding: '16px',
              zIndex: 22,
              maxHeight: '400px',
              overflowY: 'auto',
            }}
          >
            <div style={{
              fontFamily: '"Space Mono", monospace',
              fontSize: '12px',
              color: '#fbbf24',
              fontWeight: 700,
              letterSpacing: '0.1em',
              marginBottom: '16px',
            }}>
              🛡 SAFETY CENTER
            </div>

            {/* PPE grid */}
            <div style={{
              marginBottom: '16px',
            }}>
              <div style={{
                fontSize: '9px',
                color: '#334155',
                fontFamily: '"Space Mono", monospace',
                letterSpacing: '0.08em',
                marginBottom: '8px',
              }}>
                PERSONAL PROTECTIVE EQUIPMENT
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                {PPE_ITEMS.map(item => (
                  <PPEButton key={item.id} item={item} />
                ))}
              </div>
            </div>

            {/* Active hazards */}
            {allHazards.length > 0 && (
              <div>
                <div style={{
                  fontSize: '9px',
                  color: '#334155',
                  fontFamily: '"Space Mono", monospace',
                  letterSpacing: '0.08em',
                  marginBottom: '8px',
                }}>
                  ACTIVE HAZARDS IN LAB
                </div>
                {allHazards.map(h => (
                  <HazardBadge key={h.code} hazard={h} />
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
