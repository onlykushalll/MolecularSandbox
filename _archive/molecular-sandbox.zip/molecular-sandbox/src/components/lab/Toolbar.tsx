'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Toolbar
// Tool modes | Beaker controls | Quick actions
// ============================================================

import { motion, AnimatePresence } from 'framer-motion';
import { useLabStore, type ToolMode } from '@/lib/store/lab-store';

const TOOLS: { id: ToolMode; icon: string; label: string; key: string }[] = [
  { id: 'select', icon: '👆', label: 'Select', key: 'S' },
  { id: 'pour',   icon: '🫗', label: 'Pour',   key: 'P' },
  { id: 'heat',   icon: '🔥', label: 'Heat',   key: 'H' },
  { id: 'stir',   icon: '🌀', label: 'Stir',   key: 'R' },
  { id: 'measure',icon: '📏', label: 'Measure', key: 'M' },
];

export default function Toolbar() {
  const {
    toolMode, setToolMode,
    selectedContainerId, containers,
    updateContainer, addContainer, removeContainer,
    startPour, stopPour, pourStream,
    checkAllContainers,
    unlimitedMode, setUnlimitedMode,
  } = useLabStore();

  const selected = containers.find(c => c.id === selectedContainerId);

  const handleToolClick = (tool: ToolMode) => {
    setToolMode(tool);
    if (tool !== 'pour') stopPour();
  };

  const handleHeatToggle = () => {
    if (!selected) return;
    updateContainer(selected.id, { isHeating: !selected.isHeating });
  };

  const handleStirToggle = () => {
    if (!selected) return;
    updateContainer(selected.id, { isStirring: !selected.isStirring });
  };

  const handleClose = () => {
    if (!selected) return;
    updateContainer(selected.id, { isClosed: !selected.isClosed });
  };

  const handleEmpty = () => {
    if (!selected) return;
    updateContainer(selected.id, {
      contents: [],
      volumeML: 0,
      color: '#c8e6ff',
      pH: 7,
      gasVolumeMol: 0,
    });
  };

  const handleAddBeaker = () => {
    const x = (Math.random() - 0.5) * 2;
    addContainer('beaker', [x, 0, 0]);
  };

  return (
    <div style={{
      position: 'absolute',
      top: 0,
      left: '260px',
      right: '240px',
      height: '52px',
      background: 'rgba(8,12,18,0.92)',
      backdropFilter: 'blur(20px)',
      borderBottom: '1px solid rgba(255,255,255,0.06)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 16px',
      gap: '8px',
      zIndex: 20,
      boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
    }}>

      {/* Logo / title */}
      <div style={{
        fontFamily: '"Space Mono", monospace',
        fontSize: '11px',
        color: '#22c55e',
        fontWeight: 700,
        letterSpacing: '0.08em',
        marginRight: '8px',
        whiteSpace: 'nowrap',
        flexShrink: 0,
      }}>
        ⚗ MOLECULAR SANDBOX
      </div>

      {/* Divider */}
      <div style={{ width: '1px', height: '24px', background: 'rgba(255,255,255,0.08)', flexShrink: 0 }} />

      {/* Tool buttons */}
      {TOOLS.map(tool => (
        <motion.button
          key={tool.id}
          onClick={() => handleToolClick(tool.id)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          title={`${tool.label} [${tool.key}]`}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '2px',
            padding: '5px 10px',
            background: toolMode === tool.id
              ? 'rgba(34,197,94,0.18)'
              : 'rgba(255,255,255,0.03)',
            border: `1px solid ${toolMode === tool.id
              ? 'rgba(34,197,94,0.5)'
              : 'rgba(255,255,255,0.07)'}`,
            borderRadius: '8px',
            cursor: 'pointer',
            flexShrink: 0,
          }}
        >
          <span style={{ fontSize: '14px', lineHeight: 1 }}>{tool.icon}</span>
          <span style={{
            fontSize: '7px',
            fontFamily: '"Space Mono", monospace',
            color: toolMode === tool.id ? '#22c55e' : '#475569',
            letterSpacing: '0.05em',
          }}>
            {tool.label}
          </span>
        </motion.button>
      ))}

      {/* Divider */}
      <div style={{ width: '1px', height: '24px', background: 'rgba(255,255,255,0.08)', flexShrink: 0 }} />

      {/* Selected container actions */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            style={{ display: 'flex', gap: '6px', alignItems: 'center' }}
          >
            {/* Heat toggle */}
            <ActionButton
              icon="🔥"
              label="HEAT"
              active={selected.isHeating}
              activeColor="#f97316"
              onClick={handleHeatToggle}
              title={selected.isHeating ? 'Stop heating' : 'Start heating'}
            />

            {/* Stir toggle */}
            <ActionButton
              icon="🌀"
              label="STIR"
              active={selected.isStirring}
              activeColor="#60a5fa"
              onClick={handleStirToggle}
              title={selected.isStirring ? 'Stop stirring' : 'Start stirring'}
            />

            {/* Cap toggle */}
            <ActionButton
              icon={selected.isClosed ? '🔒' : '🔓'}
              label={selected.isClosed ? 'SEALED' : 'OPEN'}
              active={selected.isClosed}
              activeColor="#a78bfa"
              onClick={handleClose}
              title={selected.isClosed ? 'Unseal container' : 'Seal container'}
            />

            {/* Empty */}
            <ActionButton
              icon="🗑"
              label="EMPTY"
              active={false}
              activeColor="#f87171"
              onClick={handleEmpty}
              title="Empty container"
            />

            <div style={{ width: '1px', height: '24px', background: 'rgba(255,255,255,0.08)' }} />

            {/* Check reactions */}
            <ActionButton
              icon="⚡"
              label="REACT"
              active={false}
              activeColor="#fbbf24"
              onClick={checkAllContainers}
              title="Manually trigger reaction check"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Spacer */}
      <div style={{ flex: 1 }} />

      {/* Add container */}
      <motion.button
        onClick={handleAddBeaker}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        style={{
          padding: '5px 12px',
          background: 'rgba(34,197,94,0.1)',
          border: '1px solid rgba(34,197,94,0.3)',
          borderRadius: '8px',
          color: '#22c55e',
          fontSize: '11px',
          fontFamily: '"Space Mono", monospace',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '5px',
          flexShrink: 0,
        }}
      >
        + BEAKER
      </motion.button>

      {/* Unlimited mode toggle */}
      <motion.button
        onClick={() => setUnlimitedMode(!unlimitedMode)}
        whileHover={{ scale: 1.02 }}
        style={{
          padding: '5px 10px',
          background: unlimitedMode ? 'rgba(167,139,250,0.12)' : 'rgba(255,255,255,0.03)',
          border: `1px solid ${unlimitedMode ? 'rgba(167,139,250,0.4)' : 'rgba(255,255,255,0.07)'}`,
          borderRadius: '8px',
          color: unlimitedMode ? '#a78bfa' : '#475569',
          fontSize: '9px',
          fontFamily: '"Space Mono", monospace',
          cursor: 'pointer',
          flexShrink: 0,
          letterSpacing: '0.05em',
        }}
      >
        ∞ {unlimitedMode ? 'UNLIMITED' : 'ECONOMY'}
      </motion.button>
    </div>
  );
}

function ActionButton({
  icon, label, active, activeColor, onClick, title,
}: {
  icon: string;
  label: string;
  active: boolean;
  activeColor: string;
  onClick: () => void;
  title?: string;
}) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      title={title}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '2px',
        padding: '5px 9px',
        background: active ? `${activeColor}18` : 'rgba(255,255,255,0.03)',
        border: `1px solid ${active ? `${activeColor}55` : 'rgba(255,255,255,0.07)'}`,
        borderRadius: '7px',
        cursor: 'pointer',
        flexShrink: 0,
        boxShadow: active ? `0 0 8px ${activeColor}33` : 'none',
      }}
    >
      <span style={{ fontSize: '13px', lineHeight: 1 }}>{icon}</span>
      <span style={{
        fontSize: '7px',
        fontFamily: '"Space Mono", monospace',
        color: active ? activeColor : '#475569',
        letterSpacing: '0.04em',
      }}>
        {label}
      </span>
    </motion.button>
  );
}
