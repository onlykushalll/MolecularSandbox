'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Reaction Alert Overlay
// Animated toasts for reactions, safety violations, gas events
// ============================================================

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLabStore } from '@/lib/store/lab-store';
import type { ReactionEvent } from '@/lib/chemistry/types';

interface AlertToast {
  id: string;
  type: 'reaction' | 'safety' | 'gas' | 'precipitate';
  title: string;
  body: string;
  color: string;
  icon: string;
}

export default function ReactionAlert() {
  const { activeReactions, safetyViolations } = useLabStore();
  const [toasts, setToasts] = useState<AlertToast[]>([]);
  const [seenReactions, setSeenReactions] = useState<Set<string>>(new Set());
  const [seenViolations, setSeenViolations] = useState<Set<string>>(new Set());

  // React to new reactions
  useEffect(() => {
    const latest = activeReactions[activeReactions.length - 1];
    if (!latest || seenReactions.has(latest.id)) return;

    setSeenReactions(prev => new Set([...prev, latest.id]));

    const isExothermic = latest.deltaHTotal < 0;
    const toastId = `rxn-${latest.id}`;

    const newToast: AlertToast = {
      id: toastId,
      type: 'reaction',
      title: isExothermic ? '⚡ Exothermic Reaction!' : '🧊 Endothermic Reaction',
      body: [
        `ΔH = ${latest.deltaHTotal.toFixed(2)} kJ`,
        `ΔT = ${latest.temperatureChange > 0 ? '+' : ''}${latest.temperatureChange.toFixed(1)}°C`,
        latest.producedGas ? `Gas: ${latest.producedGas} evolved` : '',
        latest.producedPrecipitate ? `Precipitate: ${latest.producedPrecipitate}` : '',
      ].filter(Boolean).join(' · '),
      color: isExothermic ? '#f97316' : '#60a5fa',
      icon: isExothermic ? '🔥' : '❄️',
    };

    addToast(newToast);

    // Gas sub-toast
    if (latest.producedGas) {
      setTimeout(() => addToast({
        id: `gas-${latest.id}`,
        type: 'gas',
        title: `${latest.producedGas} gas evolved`,
        body: 'Ensure fume hood is active if toxic.',
        color: '#fbbf24',
        icon: '💨',
      }), 600);
    }

    // Precipitate sub-toast
    if (latest.producedPrecipitate) {
      setTimeout(() => addToast({
        id: `ppt-${latest.id}`,
        type: 'precipitate',
        title: `${latest.producedPrecipitate} precipitate`,
        body: 'Solid settling visible in container.',
        color: '#a78bfa',
        icon: '⬇️',
      }), 900);
    }
  }, [activeReactions]);

  // React to safety violations
  useEffect(() => {
    if (safetyViolations.length === 0) return;
    const latest = safetyViolations[safetyViolations.length - 1];
    if (seenViolations.has(latest)) return;

    setSeenViolations(prev => new Set([...prev, latest]));

    addToast({
      id: `safety-${Date.now()}`,
      type: 'safety',
      title: '⚠️ Safety Alert',
      body: latest,
      color: '#f87171',
      icon: '🚨',
    });
  }, [safetyViolations]);

  function addToast(toast: AlertToast) {
    setToasts(prev => [...prev.slice(-4), toast]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== toast.id));
    }, 4500);
  }

  return (
    <div style={{
      position: 'absolute',
      top: '64px',
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '8px',
      zIndex: 50,
      pointerEvents: 'none',
      width: '420px',
    }}>
      <AnimatePresence>
        {toasts.map(toast => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            style={{
              background: `rgba(8,12,18,0.92)`,
              border: `1px solid ${toast.color}44`,
              borderLeft: `3px solid ${toast.color}`,
              borderRadius: '10px',
              padding: '10px 16px',
              backdropFilter: 'blur(20px)',
              boxShadow: `0 4px 24px rgba(0,0,0,0.4), 0 0 12px ${toast.color}22`,
              width: '100%',
              display: 'flex',
              gap: '10px',
              alignItems: 'flex-start',
            }}
          >
            <span style={{ fontSize: '18px', flexShrink: 0, marginTop: '1px' }}>
              {toast.icon}
            </span>
            <div style={{ flex: 1 }}>
              <div style={{
                fontFamily: '"Space Mono", monospace',
                fontSize: '11px',
                color: toast.color,
                fontWeight: 700,
                marginBottom: '3px',
                letterSpacing: '0.04em',
              }}>
                {toast.title}
              </div>
              <div style={{
                fontSize: '9px',
                color: '#64748b',
                fontFamily: '"Space Mono", monospace',
                lineHeight: 1.5,
              }}>
                {toast.body}
              </div>
            </div>

            {/* Progress bar */}
            <motion.div
              initial={{ scaleX: 1 }}
              animate={{ scaleX: 0 }}
              transition={{ duration: 4.5, ease: 'linear' }}
              style={{
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0,
                height: '2px',
                background: toast.color,
                borderRadius: '0 0 10px 10px',
                transformOrigin: 'left',
                opacity: 0.6,
              }}
            />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
