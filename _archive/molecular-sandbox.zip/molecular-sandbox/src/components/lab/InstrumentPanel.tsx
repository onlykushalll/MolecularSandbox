'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Instrument Panel
// Live sensors: pH meter | Thermometer | Pressure gauge
// ============================================================

import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { useLabStore } from '@/lib/store/lab-store';
import type { ContainerState } from '@/lib/chemistry/types';

function pHColor(pH: number): string {
  if (pH < 2) return '#ff2200';
  if (pH < 4) return '#ff6600';
  if (pH < 6) return '#ffaa00';
  if (pH < 6.9) return '#aacc00';
  if (pH <= 7.1) return '#22cc44';
  if (pH <= 9) return '#2299ff';
  if (pH <= 11) return '#4455ff';
  return '#8800ff';
}

function pHLabel(pH: number): string {
  if (pH < 2) return 'STRONGLY ACIDIC';
  if (pH < 4) return 'ACIDIC';
  if (pH < 6.5) return 'WEAKLY ACIDIC';
  if (pH <= 7.5) return 'NEUTRAL';
  if (pH <= 9) return 'WEAKLY ALKALINE';
  if (pH <= 11) return 'ALKALINE';
  return 'STRONGLY ALKALINE';
}

function GaugeDial({
  value, min, max, unit, label, color, size = 80,
}: {
  value: number; min: number; max: number;
  unit: string; label: string; color: string; size?: number;
}) {
  const pct = Math.min(Math.max((value - min) / (max - min), 0), 1);
  const angle = -135 + pct * 270; // sweep 270°
  const r = size * 0.38;
  const cx = size / 2;
  const cy = size / 2;

  // Arc path
  const startAngle = -135 * (Math.PI / 180);
  const endAngle = (angle) * (Math.PI / 180);
  const arcX = cx + r * Math.cos(endAngle);
  const arcY = cy + r * Math.sin(endAngle);
  const startX = cx + r * Math.cos(startAngle);
  const startY = cy + r * Math.sin(startAngle);
  const largeArc = pct > 0.5 ? 1 : 0;

  return (
    <div style={{ textAlign: 'center' }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {/* Track */}
        <circle
          cx={cx} cy={cy} r={r}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="4"
          strokeDasharray={`${r * 2 * Math.PI * 0.75} ${r * 2 * Math.PI * 0.25}`}
          strokeDashoffset={r * 2 * Math.PI * 0.375}
          strokeLinecap="round"
        />
        {/* Active arc */}
        {pct > 0 && (
          <path
            d={`M ${startX} ${startY} A ${r} ${r} 0 ${largeArc} 1 ${arcX} ${arcY}`}
            fill="none"
            stroke={color}
            strokeWidth="4"
            strokeLinecap="round"
            opacity={0.9}
          />
        )}
        {/* Needle */}
        <line
          x1={cx}
          y1={cy}
          x2={cx + (r - 6) * Math.cos(endAngle)}
          y2={cy + (r - 6) * Math.sin(endAngle)}
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
        />
        {/* Center dot */}
        <circle cx={cx} cy={cy} r="3" fill={color} />
        {/* Value */}
        <text
          x={cx} y={cy + r * 0.5}
          textAnchor="middle"
          fill="#e2e8f0"
          fontSize={size * 0.14}
          fontFamily="Space Mono, monospace"
          fontWeight="bold"
        >
          {value.toFixed(1)}
        </text>
        <text
          x={cx} y={cy + r * 0.5 + size * 0.12}
          textAnchor="middle"
          fill="rgba(255,255,255,0.4)"
          fontSize={size * 0.1}
          fontFamily="Space Mono, monospace"
        >
          {unit}
        </text>
      </svg>
      <div style={{
        fontSize: '9px',
        color: 'rgba(255,255,255,0.4)',
        fontFamily: '"Space Mono", monospace',
        letterSpacing: '0.05em',
        marginTop: '-4px',
      }}>
        {label}
      </div>
    </div>
  );
}

function PHStrip({ pH }: { pH: number }) {
  const color = pHColor(pH);
  const label = pHLabel(pH);

  return (
    <div style={{ marginBottom: '12px' }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '6px',
      }}>
        <span style={{
          fontFamily: '"Space Mono", monospace',
          fontSize: '11px',
          color: '#64748b',
        }}>
          pH METER
        </span>
        <span style={{
          fontFamily: '"Space Mono", monospace',
          fontSize: '13px',
          color,
          fontWeight: 700,
          textShadow: `0 0 8px ${color}66`,
        }}>
          {pH.toFixed(2)}
        </span>
      </div>

      {/* pH spectrum bar */}
      <div style={{
        height: '8px',
        borderRadius: '4px',
        background: 'linear-gradient(to right, #ff0000, #ff6600, #ffaa00, #ffff00, #00cc44, #0099ff, #0044ff, #8800ff)',
        position: 'relative',
        marginBottom: '4px',
      }}>
        <motion.div
          animate={{ left: `${(pH / 14) * 100}%` }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          style={{
            position: 'absolute',
            top: '-4px',
            width: '4px',
            height: '16px',
            background: '#fff',
            borderRadius: '2px',
            transform: 'translateX(-50%)',
            boxShadow: '0 0 6px rgba(255,255,255,0.8)',
          }}
        />
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '8px', color: '#334155' }}>
        <span>0</span>
        <span style={{ color, fontSize: '9px' }}>{label}</span>
        <span>14</span>
      </div>
    </div>
  );
}

function ContainerDetails({ container }: { container: ContainerState }) {
  const totalMass = container.contents.reduce((s, c) => s + c.massGrams, 0);

  return (
    <div style={{
      background: 'rgba(255,255,255,0.02)',
      border: '1px solid rgba(255,255,255,0.06)',
      borderRadius: '8px',
      padding: '10px',
      marginBottom: '8px',
    }}>
      <div style={{
        fontFamily: '"Space Mono", monospace',
        fontSize: '10px',
        color: '#22c55e',
        marginBottom: '8px',
        display: 'flex',
        justifyContent: 'space-between',
      }}>
        <span>{container.type.toUpperCase()}</span>
        <span style={{ color: '#334155' }}>
          {container.volumeML.toFixed(1)}/{container.capacityML}mL
        </span>
      </div>

      {/* Volume bar */}
      <div style={{
        height: '4px',
        background: 'rgba(255,255,255,0.08)',
        borderRadius: '2px',
        marginBottom: '10px',
      }}>
        <motion.div
          animate={{ width: `${(container.volumeML / container.capacityML) * 100}%` }}
          transition={{ type: 'spring', stiffness: 150 }}
          style={{
            height: '100%',
            borderRadius: '2px',
            background: container.color,
            boxShadow: `0 0 4px ${container.color}88`,
          }}
        />
      </div>

      {/* Instruments */}
      <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '10px' }}>
        <GaugeDial
          value={container.temperatureC}
          min={-20} max={400}
          unit="°C" label="TEMP"
          color={container.temperatureC > 100 ? '#ff6600' : container.temperatureC > 50 ? '#ffaa00' : '#22c55e'}
          size={76}
        />
        <GaugeDial
          value={container.pressureKPa}
          min={80} max={500}
          unit="kPa" label="PRESSURE"
          color={container.pressureKPa > 200 ? '#ff4444' : '#4488ff'}
          size={76}
        />
      </div>

      {/* pH strip */}
      {container.volumeML > 0 && <PHStrip pH={container.pH} />}

      {/* Contents breakdown */}
      {container.contents.length > 0 && (
        <div>
          <div style={{
            fontSize: '9px', color: '#334155',
            fontFamily: '"Space Mono", monospace',
            marginBottom: '5px', letterSpacing: '0.05em',
          }}>
            CONTENTS
          </div>
          {container.contents.map(comp => (
            <div key={comp.formula} style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontSize: '10px',
              color: '#64748b',
              marginBottom: '3px',
            }}>
              <span style={{ fontFamily: '"Space Mono", monospace', color: '#94a3b8' }}>
                {comp.formula}
              </span>
              <span>{comp.massGrams.toFixed(2)}g</span>
              <span style={{ color: '#334155' }}>
                {totalMass > 0 ? ((comp.massGrams / totalMass) * 100).toFixed(0) : 0}%
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Gas indicator */}
      {container.gasVolumeMol > 0.001 && (
        <div style={{
          marginTop: '8px',
          padding: '5px 8px',
          background: 'rgba(255,238,0,0.06)',
          border: '1px solid rgba(255,238,0,0.2)',
          borderRadius: '4px',
          fontSize: '9px',
          color: '#ffee00',
          fontFamily: '"Space Mono", monospace',
        }}>
          ⚗ GAS: {container.gasVolumeMol.toFixed(4)} mol
        </div>
      )}
    </div>
  );
}

export default function InstrumentPanel() {
  const { containers, selectedContainerId, isPanelOpen, togglePanel, activeReactions } = useLabStore();

  const isOpen = isPanelOpen['instruments'];
  const selectedContainer = containers.find(c => c.id === selectedContainerId) ?? containers[0];

  return (
    <motion.div
      initial={false}
      animate={{ width: isOpen ? '240px' : '42px' }}
      style={{
        position: 'absolute',
        right: 0, top: 0, bottom: 0,
        background: 'rgba(10,14,20,0.88)',
        backdropFilter: 'blur(20px)',
        borderLeft: '1px solid rgba(255,255,255,0.07)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        zIndex: 20,
        boxShadow: '-4px 0 24px rgba(0,0,0,0.4)',
      }}
    >
      {/* Toggle */}
      <button
        onClick={() => togglePanel('instruments')}
        style={{
          width: '42px',
          height: '42px',
          alignSelf: 'flex-end',
          flexShrink: 0,
          background: 'transparent',
          border: 'none',
          color: '#4488ff',
          fontSize: '18px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {isOpen ? '▶' : '📊'}
      </button>

      {isOpen && selectedContainer && (
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '0 10px 10px',
          scrollbarWidth: 'thin',
          scrollbarColor: '#22c55e22 transparent',
        }}>
          <div style={{
            fontFamily: '"Space Mono", monospace',
            fontSize: '11px',
            color: '#4488ff',
            letterSpacing: '0.1em',
            fontWeight: 700,
            padding: '8px 2px 12px',
            borderBottom: '1px solid rgba(255,255,255,0.06)',
            marginBottom: '10px',
          }}>
            📊 INSTRUMENTS
          </div>

          <ContainerDetails container={selectedContainer} />

          {/* Recent reaction log */}
          {activeReactions.length > 0 && (
            <div style={{
              background: 'rgba(34,197,94,0.04)',
              border: '1px solid rgba(34,197,94,0.15)',
              borderRadius: '8px',
              padding: '10px',
            }}>
              <div style={{
                fontSize: '9px',
                color: '#22c55e',
                fontFamily: '"Space Mono", monospace',
                marginBottom: '6px',
                letterSpacing: '0.08em',
              }}>
                ⚡ LAST REACTION
              </div>
              {[...activeReactions].reverse().slice(0, 2).map(rxn => (
                <div key={rxn.id} style={{
                  fontSize: '9px',
                  color: '#64748b',
                  marginBottom: '5px',
                  lineHeight: 1.5,
                }}>
                  <span style={{ color: '#94a3b8' }}>ΔH: </span>
                  <span style={{ color: rxn.deltaHTotal < 0 ? '#f97316' : '#60a5fa' }}>
                    {rxn.deltaHTotal.toFixed(2)} kJ
                  </span>
                  <span style={{ color: '#334155' }}> | ΔT: </span>
                  <span style={{ color: rxn.temperatureChange > 0 ? '#f97316' : '#60a5fa' }}>
                    {rxn.temperatureChange > 0 ? '+' : ''}{rxn.temperatureChange.toFixed(1)}°C
                  </span>
                  {rxn.producedGas && (
                    <div style={{ color: '#ffee00' }}>⚗ Gas: {rxn.producedGas}</div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
