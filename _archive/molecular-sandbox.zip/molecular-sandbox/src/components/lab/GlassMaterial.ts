'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Glass GLSL Shader Material
// Physical refraction | Fresnel | Condensation | Caustics
// ============================================================

import { shaderMaterial } from '@react-three/drei';
import { extend } from '@react-three/fiber';
import * as THREE from 'three';

const GlassShaderMaterial = shaderMaterial(
  {
    uTime: 0,
    uIOR: 1.517,                // Borosilicate glass IOR
    uThickness: 0.003,          // glass wall thickness in meters
    uOpacity: 0.12,
    uEnvMap: null as THREE.CubeTexture | null,
    uCondensation: 0.0,         // 0-1 fog/condensation level
    uTint: new THREE.Color('#a8d8ea'),
    uRoughness: 0.04,
    uCrackLevel: 0.0,           // 0=intact, 1=shattered
  },

  // ── Vertex Shader ──────────────────────────────────────────
  /* glsl */ `
    varying vec3 vWorldPos;
    varying vec3 vWorldNormal;
    varying vec2 vUv;
    varying vec3 vViewDir;

    void main() {
      vUv = uv;
      vWorldPos = (modelMatrix * vec4(position, 1.0)).xyz;
      vWorldNormal = normalize(mat3(modelMatrix) * normal);
      vViewDir = normalize(cameraPosition - vWorldPos);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,

  // ── Fragment Shader ────────────────────────────────────────
  /* glsl */ `
    uniform float uTime;
    uniform float uIOR;
    uniform float uOpacity;
    uniform float uCondensation;
    uniform vec3 uTint;
    uniform float uRoughness;
    uniform float uCrackLevel;

    varying vec3 vWorldPos;
    varying vec3 vWorldNormal;
    varying vec2 vUv;
    varying vec3 vViewDir;

    // Schlick Fresnel
    float schlick(float cosTheta, float ior) {
      float r0 = pow((1.0 - ior) / (1.0 + ior), 2.0);
      return r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
    }

    // Voronoi noise for condensation droplets
    vec2 voronoi(vec2 x) {
      vec2 p = floor(x);
      vec2 f = fract(x);
      float res = 8.0;
      vec2 mr = vec2(0.0);
      for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
          vec2 b = vec2(float(i), float(j));
          vec2 r = b - f + fract(sin(dot(p + b, vec2(127.1, 311.7))) * 43758.5453);
          float d = dot(r, r);
          if (d < res) {
            res = d;
            mr = r;
          }
        }
      }
      return mr;
    }

    // Crack pattern SDF
    float crackPattern(vec2 uv) {
      float c = 0.0;
      c += step(0.97, sin(uv.x * 20.0 + uv.y * 15.0));
      c += step(0.98, sin(uv.x * 13.0 - uv.y * 22.0));
      return c;
    }

    void main() {
      vec3 N = normalize(vWorldNormal);
      vec3 V = normalize(vViewDir);
      float NdotV = max(dot(N, V), 0.0);

      // Fresnel — glass edge glow
      float F = schlick(NdotV, uIOR);

      // Transmission color
      vec3 glassColor = uTint * (1.0 - F * 0.6);

      // Condensation using Voronoi droplets
      float condensationMask = 0.0;
      if (uCondensation > 0.01) {
        vec2 dropUV = vUv * 18.0;
        vec2 vor = voronoi(dropUV + uTime * 0.05);
        float droplet = smoothstep(0.3, 0.0, length(vor));
        float streaks = smoothstep(0.95, 1.0, sin(vUv.y * 40.0 + uTime * 0.3));
        condensationMask = (droplet + streaks * 0.3) * uCondensation;
        glassColor = mix(glassColor, vec3(0.85, 0.92, 0.98), condensationMask * 0.5);
      }

      // Specular highlight
      vec3 L = normalize(vec3(2.0, 3.0, 2.0));
      vec3 H = normalize(V + L);
      float spec = pow(max(dot(N, H), 0.0), 128.0) * 0.8;
      glassColor += vec3(spec);

      // Rim light (lab environment light)
      float rim = pow(1.0 - NdotV, 3.0) * 0.25;
      glassColor += vec3(0.8, 0.9, 1.0) * rim;

      // Crack overlay
      if (uCrackLevel > 0.01) {
        float crack = crackPattern(vUv) * uCrackLevel;
        glassColor = mix(glassColor, vec3(0.8, 0.85, 0.9), crack * 0.7);
      }

      float alpha = mix(uOpacity, 0.65, F) + condensationMask * 0.2;
      gl_FragColor = vec4(glassColor, clamp(alpha, 0.05, 0.85));
    }
  `
);

extend({ GlassShaderMaterial });

export { GlassShaderMaterial };
export default GlassShaderMaterial;
