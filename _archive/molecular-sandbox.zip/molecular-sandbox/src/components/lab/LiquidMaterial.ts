'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Liquid GLSL Shader Material
// Beer-Lambert absorption | Meniscus | Wobble | Fresnel
// ============================================================

import { shaderMaterial } from '@react-three/drei';
import { extend, type ReactThreeFiber } from '@react-three/fiber';
import * as THREE from 'three';

const LiquidShaderMaterial = shaderMaterial(
  // Uniforms
  {
    uTime: 0,
    uFillAmount: 0.5,           // 0-1 fill level
    uColor: new THREE.Color('#4488ff'),
    uViscosity: 0.5,            // 0=water, 1=syrup
    uRefractiveIndex: 1.33,
    uAbsorptionCoeff: 0.8,      // Beer-Lambert opacity
    uWobbleAmplitude: 0.015,
    uIsStirring: 0,
    uStirSpeed: 0,
    uResolution: new THREE.Vector2(1, 1),
    uSurfaceTension: 0.5,
  },

  // ── Vertex Shader ──────────────────────────────────────────
  /* glsl */ `
    uniform float uTime;
    uniform float uFillAmount;
    uniform float uViscosity;
    uniform float uWobbleAmplitude;
    uniform float uIsStirring;
    uniform float uStirSpeed;
    uniform float uSurfaceTension;

    varying vec3 vWorldPos;
    varying vec3 vLocalPos;
    varying vec3 vNormal;
    varying float vDepth;

    // FastSin approximation (Bhaskara I)
    float fastSin(float x) {
      float s = mod(x, 6.28318530718);
      return 16.0 * s * (3.14159265359 - s) / (49.348 - 4.0 * s * (3.14159265359 - s));
    }

    void main() {
      vLocalPos = position;
      vNormal = normal;

      vec3 pos = position;

      // Fill cutoff
      float fillHeight = uFillAmount * 2.0 - 1.0; // map 0-1 to -1..1 space
      if (pos.y > fillHeight + 0.001) {
        gl_Position = vec4(0.0);
        return;
      }

      // Depth from surface (0 = surface, 1 = bottom)
      float depth = 1.0 - clamp((pos.y - (-1.0)) / (fillHeight - (-1.0)), 0.0, 1.0);
      vDepth = depth;

      // Wobble — decreases with viscosity, amplitude decays with depth
      float wobbleFreq = (1.0 - uViscosity) * 6.0;
      float wobble = fastSin(uTime * wobbleFreq + pos.x * 3.0) * uWobbleAmplitude * (1.0 - depth * 0.8);
      pos.y += wobble;

      // Meniscus — concave surface at walls (realistic for water wetting)
      float radialDist = length(pos.xz);
      float radius = 0.95;
      if (radialDist > radius * 0.85 && pos.y > fillHeight - 0.05) {
        float edge = (radialDist - radius * 0.85) / (radius * 0.15);
        pos.y -= edge * edge * uSurfaceTension * 0.08;
      }

      // Stirring vortex
      if (uIsStirring > 0.5) {
        float vortexStrength = uStirSpeed * 0.04 * (1.0 - depth);
        float angle = atan(pos.z, pos.x) + uTime * uStirSpeed * 2.0;
        float r = length(pos.xz);
        pos.x += -sin(angle) * vortexStrength * r;
        pos.z += cos(angle) * vortexStrength * r;
        // Vortex depression at center
        float centerDip = clamp(uStirSpeed * 0.06 * (1.0 - r * 2.0), 0.0, 0.15);
        pos.y -= centerDip;
      }

      vWorldPos = (modelMatrix * vec4(pos, 1.0)).xyz;

      gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    }
  `,

  // ── Fragment Shader ────────────────────────────────────────
  /* glsl */ `
    uniform float uTime;
    uniform float uFillAmount;
    uniform vec3 uColor;
    uniform float uViscosity;
    uniform float uRefractiveIndex;
    uniform float uAbsorptionCoeff;

    varying vec3 vWorldPos;
    varying vec3 vLocalPos;
    varying vec3 vNormal;
    varying float vDepth;

    // Schlick Fresnel approximation
    float fresnel(vec3 viewDir, vec3 normal, float ior) {
      float f0 = pow((1.0 - ior) / (1.0 + ior), 2.0);
      return f0 + (1.0 - f0) * pow(1.0 - max(dot(viewDir, normal), 0.0), 5.0);
    }

    // Beer-Lambert opacity
    float beerLambert(float absorptionCoeff, float depth) {
      return 1.0 - exp(-absorptionCoeff * depth);
    }

    void main() {
      // View direction
      vec3 viewDir = normalize(cameraPosition - vWorldPos);

      // Beer-Lambert — thicker liquid = more opaque
      float opacity = beerLambert(uAbsorptionCoeff, vDepth * 2.0 + 0.3);
      opacity = clamp(opacity, 0.4, 0.92);

      // Base color with depth darkening
      vec3 deepColor = uColor * 0.6;
      vec3 surfaceColor = uColor * 1.2;
      vec3 liquidColor = mix(surfaceColor, deepColor, vDepth);

      // Subsurface scattering approximation
      float scatter = exp(-vDepth * 3.0) * 0.3;
      liquidColor += scatter * vec3(1.0, 1.0, 1.0) * (1.0 - uViscosity * 0.5);

      // Fresnel at surface normal
      float F = fresnel(viewDir, vNormal, uRefractiveIndex);
      vec3 fresnelColor = vec3(1.0, 1.0, 1.0) * F * 0.4;

      // Specular highlight
      vec3 lightDir = normalize(vec3(1.0, 2.0, 1.0));
      vec3 halfVec = normalize(viewDir + lightDir);
      float specPower = mix(32.0, 256.0, 1.0 - uViscosity);
      float spec = pow(max(dot(vNormal, halfVec), 0.0), specPower) * 0.6;

      vec3 finalColor = liquidColor + fresnelColor + vec3(spec);

      gl_FragColor = vec4(finalColor, opacity);
    }
  `
);

extend({ LiquidShaderMaterial });

declare module '@react-three/fiber' {
  interface ThreeElements {
    liquidShaderMaterial: ReactThreeFiber.Object3DNode<
      typeof LiquidShaderMaterial & THREE.ShaderMaterial,
      typeof LiquidShaderMaterial
    >;
  }
}

export { LiquidShaderMaterial };
export default LiquidShaderMaterial;
