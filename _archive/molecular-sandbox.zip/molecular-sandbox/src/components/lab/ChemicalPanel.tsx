'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Chemical Panel
// Glassmorphism sidebar | Drag-to-pour | GHS hazards
// ============================================================

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLabStore } from '@/lib/store/lab-store';
import { CHEMICALS, CHEMICAL_MAP } from '@/lib/chemistry/data';
import type { ChemicalData } from '@/lib/chemistry/types';

const CATEGORIES = [
  { id: 'all', label: 'All', icon: '⚗️' },
  { id: 'acid', label: 'Acids', icon: '🧪' },
  { id: 'base', label: 'Bases', icon: '🔵' },
  { id: 'salt', label: 'Salts', icon: '🧂' },
  { id: 'metal', label: 'Metals', icon: '⚙️' },
  { id: 'gas', label: 'Gases', icon: '💨' },
  { id: 'solvent', label: 'Solvents', icon: '💧' },
  { id: 'indicator', label: 'Indicators', icon: '🌈' },
  { id: 'oxidizer', label: 'Oxidizers', icon: '🔥' },
  { id: 'catalyst', label: 'Catalysts', icon: '⚡' },
];

interface ChemicalCardProps {
  chemical: ChemicalData;
  onAdd: (formula: string, mass: number) => void;
  targetId: string | null;
}

function ChemicalCard({ chemical, onAdd, targetId }: ChemicalCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [addMass, setAddMass] = useState(10);
  const { setDraggingChemical } = useLabStore();

  const stateColor: Record<string, string> = {
    solid: '#f0e68c',
    liquid: '#87ceeb',
    gas: '#d3d3d3',
    aqueous: '#4fc3f7',
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('chemical', chemical.id);
    setDraggingChemical(chemical.id);
  };

  const handleDragEnd = () => {
    setDraggingChemical(null);
  };

  const handleAdd = () => {
    if (!targetId) return;
    onAdd(chemical.id, addMass);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onClick={() => setIsExpanded(!isExpanded)}
      style={{
        background: 'rgba(255,255,255,0.04)',
        border: `1px solid rgba(255,255,255,0.08)`,
        borderLeft: `3px solid ${chemical.hexColor}`,
        borderRadius: '8px',
        padding: '10px 12px',
        cursor: 'grab',
        userSelect: 'none',
        transition: 'background 0.15s',
        marginBottom: '4px',
      }}
      whileHover={{ background: 'rgba(255,255,255,0.08)' }}
      whileTap={{ scale: 0.98 }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        {/* Color swatch */}
        <div style={{
          width: '24px', height: '24px',
          borderRadius: '50%',
          background: chemical.hexColor,
          border: '1px solid rgba(255,255,255,0.2)',
          flexShrink: 0,
          boxShadow: `0 0 8px ${chemical.hexColor}44`,
        }} />

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <span style={{
              fontFamily: '"Space Mono", monospace',
              fontSize: '12px',
              color: '#e2e8f0',
              fontWeight: 600,
            }}>
              {chemical.formula}
            </span>
            <span style={{
              fontSize: '9px',
              color: stateColor[chemical.stateAtSTP] ?? '#888',
              background: 'rgba(255,255,255,0.06)',
              padding: '1px 5px',
              borderRadius: '3px',
            }}>
              {chemical.stateAtSTP.toUpperCase()}
            </span>
          </div>
          <div style={{
            fontSize: '10px',
            color: '#94a3b8',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            marginTop: '1px',
          }}>
            {chemical.name}
          </div>
        </div>

        {/* Hazard icons */}
        <div style={{ display: 'flex', gap: '2px', flexShrink: 0 }}>
          {chemical.hazards.slice(0, 2).map(h => (
            <span key={h.code} title={h.category} style={{ fontSize: '11px' }}>
              {h.symbol}
            </span>
          ))}
        </div>
      </div>

      {/* Expanded details */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            style={{ overflow: 'hidden' }}
          >
            <div style={{
              marginTop: '10px',
              paddingTop: '8px',
              borderTop: '1px solid rgba(255,255,255,0.06)',
              fontSize: '10px',
              color: '#64748b',
              lineHeight: 1.7,
            }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2px 12px' }}>
                <span>M: <b style={{ color: '#94a3b8' }}>{chemical.molarMass} g/mol</b></span>
                <span>ρ: <b style={{ color: '#94a3b8' }}>{chemical.density} g/mL</b></span>
                <span>BP: <b style={{ color: '#94a3b8' }}>{chemical.boilingPoint}°C</b></span>
                <span>MP: <b style={{ color: '#94a3b8' }}>{chemical.meltingPoint}°C</b></span>
                {chemical.pKa !== undefined && (
                  <span>pKa: <b style={{ color: '#f97316' }}>{chemical.pKa}</b></span>
                )}
                {chemical.pKb !== undefined && (
                  <span>pKb: <b style={{ color: '#3b82f6' }}>{chemical.pKb}</b></span>
                )}
              </div>

              <p style={{ margin: '6px 0 0', color: '#475569', fontSize: '9px' }}>
                {chemical.description}
              </p>

              {/* Add to beaker */}
              <div style={{
                display: 'flex', gap: '6px', marginTop: '8px', alignItems: 'center',
              }}>
                <input
                  type="number"
                  value={addMass}
                  onChange={e => setAddMass(Number(e.target.value))}
                  onClick={e => e.stopPropagation()}
                  min={0.1}
                  max={1000}
                  step={0.5}
                  style={{
                    width: '60px',
                    background: 'rgba(255,255,255,0.06)',
                    border: '1px solid rgba(255,255,255,0.12)',
                    borderRadius: '4px',
                    color: '#e2e8f0',
                    padding: '3px 6px',
                    fontSize: '11px',
                    outline: 'none',
                  }}
                />
                <span style={{ color: '#475569', fontSize: '10px' }}>g</span>
                <button
                  onClick={(e) => { e.stopPropagation(); handleAdd(); }}
                  disabled={!targetId}
                  style={{
                    flex: 1,
                    background: targetId ? '#22c55e22' : '#33333322',
                    border: `1px solid ${targetId ? '#22c55e44' : '#33333344'}`,
                    borderRadius: '4px',
                    color: targetId ? '#22c55e' : '#444',
                    padding: '3px 8px',
                    fontSize: '10px',
                    cursor: targetId ? 'pointer' : 'not-allowed',
                    fontFamily: '"Space Mono", monospace',
                  }}
                >
                  {targetId ? '+ ADD' : 'SELECT BEAKER'}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function ChemicalPanel() {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const { isPanelOpen, togglePanel, selectedContainerId, addChemicalToContainer } = useLabStore();

  const isOpen = isPanelOpen['chemicals'];

  const filtered = useMemo(() => {
    return CHEMICALS.filter(c => {
      const matchCat = activeCategory === 'all' || c.category === activeCategory;
      const matchSearch = !search
        || c.name.toLowerCase().includes(search.toLowerCase())
        || c.formula.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [activeCategory, search]);

  return (
    <motion.div
      initial={false}
      animate={{ width: isOpen ? '260px' : '42px' }}
      style={{
        position: 'absolute',
        left: 0, top: 0, bottom: 0,
        background: 'rgba(10,14,20,0.88)',
        backdropFilter: 'blur(20px)',
        borderRight: '1px solid rgba(255,255,255,0.07)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        zIndex: 20,
        boxShadow: '4px 0 24px rgba(0,0,0,0.4)',
      }}
    >
      {/* Toggle button */}
      <button
        onClick={() => togglePanel('chemicals')}
        style={{
          width: '42px',
          height: '42px',
          flexShrink: 0,
          background: 'transparent',
          border: 'none',
          color: '#22c55e',
          fontSize: '18px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        title={isOpen ? 'Close panel' : 'Open chemicals'}
      >
        {isOpen ? '◀' : '⚗'}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              padding: '0 10px 10px',
              overflow: 'hidden',
              width: '260px',
            }}
          >
            {/* Header */}
            <div style={{
              padding: '8px 2px 12px',
              borderBottom: '1px solid rgba(255,255,255,0.06)',
              marginBottom: '10px',
            }}>
              <div style={{
                fontFamily: '"Space Mono", monospace',
                fontSize: '11px',
                color: '#22c55e',
                letterSpacing: '0.1em',
                fontWeight: 700,
              }}>
                ⚗ CHEMICAL LIBRARY
              </div>
              <div style={{ fontSize: '9px', color: '#334155', marginTop: '2px' }}>
                {filtered.length} compounds available
              </div>
            </div>

            {/* Search */}
            <input
              type="text"
              placeholder="Search by name or formula..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '6px',
                color: '#e2e8f0',
                padding: '7px 10px',
                fontSize: '11px',
                outline: 'none',
                marginBottom: '8px',
                fontFamily: '"Space Mono", monospace',
              }}
            />

            {/* Category tabs */}
            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '4px',
              marginBottom: '10px',
            }}>
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  style={{
                    padding: '3px 7px',
                    borderRadius: '4px',
                    fontSize: '9px',
                    fontFamily: '"Space Mono", monospace',
                    cursor: 'pointer',
                    background: activeCategory === cat.id
                      ? 'rgba(34,197,94,0.2)'
                      : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${activeCategory === cat.id
                      ? 'rgba(34,197,94,0.5)'
                      : 'rgba(255,255,255,0.07)'}`,
                    color: activeCategory === cat.id ? '#22c55e' : '#64748b',
                  }}
                >
                  {cat.icon} {cat.label}
                </button>
              ))}
            </div>

            {/* Target indicator */}
            <div style={{
              fontSize: '9px',
              color: selectedContainerId ? '#22c55e' : '#334155',
              fontFamily: '"Space Mono", monospace',
              marginBottom: '8px',
              padding: '5px 8px',
              background: selectedContainerId
                ? 'rgba(34,197,94,0.08)'
                : 'rgba(255,255,255,0.02)',
              borderRadius: '4px',
              border: `1px solid ${selectedContainerId
                ? 'rgba(34,197,94,0.2)'
                : 'rgba(255,255,255,0.04)'}`,
            }}>
              {selectedContainerId
                ? `▶ Selected: ${selectedContainerId.slice(0, 12)}...`
                : '○ Click a beaker to select target'}
            </div>

            {/* Chemical list */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              overflowX: 'hidden',
              scrollbarWidth: 'thin',
              scrollbarColor: '#22c55e22 transparent',
            }}>
              <AnimatePresence>
                {filtered.map(chem => (
                  <ChemicalCard
                    key={chem.id}
                    chemical={chem}
                    targetId={selectedContainerId}
                    onAdd={(formula, mass) => {
                      if (selectedContainerId) {
                        addChemicalToContainer(selectedContainerId, formula, mass);
                      }
                    }}
                  />
                ))}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
