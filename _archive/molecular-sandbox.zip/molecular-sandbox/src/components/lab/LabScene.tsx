'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Main 3D Lab Scene
// React Three Fiber | Drei | Physics | Lighting
// ============================================================

import { Suspense, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import {
  Environment, ContactShadows, Grid, Float,
  Preload, AdaptiveDpr, AdaptiveEvents, PerformanceMonitor,
  PerspectiveCamera, OrbitControls, Stars,
} from '@react-three/drei';
import { Physics } from '@react-three/rapier';
import * as THREE from 'three';
import { useLabStore } from '@/lib/store/lab-store';
import Beaker from './Beaker';
import PourStream from './PourStream';

// ── Lab Bench ────────────────────────────────────────────────
function LabBench() {
  return (
    <group position={[0, -0.8, 0]}>
      {/* Main bench surface */}
      <mesh receiveShadow position={[0, 0, 0]}>
        <boxGeometry args={[6, 0.08, 2.5]} />
        <meshPhysicalMaterial
          color="#e8d5b0"
          roughness={0.3}
          metalness={0.0}
          clearcoat={0.6}
          clearcoatRoughness={0.1}
        />
      </mesh>

      {/* Bench edge strip */}
      <mesh position={[0, 0.05, 1.2]}>
        <boxGeometry args={[6, 0.04, 0.06]} />
        <meshPhysicalMaterial color="#2a1f0e" roughness={0.9} />
      </mesh>

      {/* Bench legs */}
      {[-2.5, 2.5].map((x, i) => (
        [-1, 1].map((z, j) => (
          <mesh key={`${i}-${j}`} position={[x, -0.65, z * 0.9]}>
            <boxGeometry args={[0.08, 1.3, 0.08]} />
            <meshPhysicalMaterial color="#2a1f0e" roughness={0.9} />
          </mesh>
        ))
      ))}

      {/* Lab mat (anti-static rubber mat) */}
      <mesh position={[0, 0.045, 0]}>
        <boxGeometry args={[5.8, 0.01, 2.3]} />
        <meshPhysicalMaterial
          color="#1a1a1a"
          roughness={0.95}
          metalness={0.0}
        />
      </mesh>

      {/* Grid lines on mat */}
      <mesh position={[0, 0.052, 0]}>
        <planeGeometry args={[5.8, 2.3]} />
        <meshBasicMaterial
          color="#333333"
          transparent
          opacity={0.3}
          wireframe
        />
      </mesh>
    </group>
  );
}

// ── Lab Room Environment ─────────────────────────────────────
function LabRoom() {
  return (
    <group>
      {/* Back wall */}
      <mesh position={[0, 1.5, -3.5]} receiveShadow>
        <planeGeometry args={[12, 6]} />
        <meshPhysicalMaterial color="#e8eaec" roughness={0.9} metalness={0} />
      </mesh>

      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.45, 0]} receiveShadow>
        <planeGeometry args={[12, 10]} />
        <meshPhysicalMaterial
          color="#c8cccf"
          roughness={0.7}
          metalness={0.1}
          reflectivity={0.3}
        />
      </mesh>

      {/* Ceiling */}
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 4, 0]}>
        <planeGeometry args={[12, 10]} />
        <meshPhysicalMaterial color="#f0f0f0" roughness={1} />
      </mesh>

      {/* Shelf on back wall */}
      <mesh position={[0, 2.4, -3.35]}>
        <boxGeometry args={[4, 0.04, 0.5]} />
        <meshPhysicalMaterial color="#c8a87a" roughness={0.6} />
      </mesh>

      {/* Fume hood outline */}
      <FumeHood />
    </group>
  );
}

// ── Fume Hood ────────────────────────────────────────────────
function FumeHood() {
  const { isInsideFumeHood } = useLabStore();

  return (
    <group position={[2.5, 0.5, -2.8]}>
      {/* Frame */}
      <mesh>
        <boxGeometry args={[1.8, 2.2, 0.8]} />
        <meshPhysicalMaterial
          color="#ccddcc"
          transparent
          opacity={0.15}
          roughness={0.1}
          wireframe
        />
      </mesh>

      {/* Sash (front glass) */}
      <mesh position={[0, -0.2, 0.4]}>
        <boxGeometry args={[1.75, 1.2, 0.02]} />
        <meshPhysicalMaterial
          color="#88aaff"
          transparent
          opacity={0.12}
          roughness={0.05}
        />
      </mesh>

      {/* Active indicator */}
      {isInsideFumeHood && (
        <pointLight color="#00ff88" intensity={0.8} distance={2} />
      )}
    </group>
  );
}

// ── Lab Lighting ─────────────────────────────────────────────
function LabLighting() {
  return (
    <>
      {/* Overhead fluorescent strips */}
      <rectAreaLight
        position={[0, 3.5, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        width={5}
        height={2}
        intensity={4}
        color="#f0f4ff"
      />

      {/* Ambient */}
      <ambientLight intensity={0.4} color="#e8eeff" />

      {/* Key light from window */}
      <directionalLight
        position={[4, 4, 2]}
        intensity={1.2}
        color="#fff5e8"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-near={0.5}
        shadow-camera-far={20}
        shadow-camera-left={-5}
        shadow-camera-right={5}
        shadow-camera-top={5}
        shadow-camera-bottom={-5}
      />

      {/* Fill from opposite side */}
      <directionalLight
        position={[-3, 2, -1]}
        intensity={0.4}
        color="#c8d8ff"
      />

      {/* Under-bench bounce */}
      <pointLight
        position={[0, -0.5, 0.5]}
        intensity={0.3}
        color="#fff0d8"
        distance={3}
      />
    </>
  );
}

// ── Heat Haze Post FX ────────────────────────────────────────
function HeatHazeEffect() {
  const { containers } = useLabStore();
  const hotContainers = containers.filter(c => c.temperatureC > 60);

  return (
    <>
      {hotContainers.map(c => (
        <Float
          key={c.id}
          speed={4}
          rotationIntensity={0}
          floatIntensity={0.01}
          floatingRange={[-0.005, 0.005]}
        >
          <mesh
            position={[c.position[0], c.position[1] + 0.9, c.position[2]]}
          >
            <planeGeometry args={[0.5, 0.6]} />
            <meshBasicMaterial
              color="#ff8800"
              transparent
              opacity={Math.min((c.temperatureC - 60) / 200, 0.06)}
              depthWrite={false}
            />
          </mesh>
        </Float>
      ))}
    </>
  );
}

// ── Gas Particles ────────────────────────────────────────────
function GasParticles() {
  const { containers } = useLabStore();
  const gasContainers = containers.filter(c => c.gasVolumeMol > 0.001);
  const meshRef = useRef<THREE.InstancedMesh>(null!);
  const dummy = new THREE.Object3D();

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const t = clock.elapsedTime;
    let idx = 0;

    for (const container of gasContainers) {
      const count = Math.min(Math.round(container.gasVolumeMol * 30), 20);
      for (let i = 0; i < count; i++) {
        const seed = idx * 7.3 + i * 2.1;
        const x = container.position[0] + Math.sin(seed + t * 0.5) * 0.3;
        const y = container.position[1] + 0.6 + ((t * (0.2 + (i % 5) * 0.05) + seed) % 1.5);
        const z = container.position[2] + Math.cos(seed + t * 0.4) * 0.2;
        dummy.position.set(x, y, z);
        dummy.scale.setScalar(0.02 + Math.sin(seed + t) * 0.008);
        dummy.updateMatrix();
        if (idx < 200) {
          meshRef.current.setMatrixAt(idx, dummy.matrix);
          idx++;
        }
      }
    }

    meshRef.current.count = idx;
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  if (gasContainers.length === 0) return null;

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, 200]}>
      <sphereGeometry args={[1, 6, 6]} />
      <meshBasicMaterial
        color="#88ff88"
        transparent
        opacity={0.25}
        depthWrite={false}
      />
    </instancedMesh>
  );
}

// ── Scene Click Handler ──────────────────────────────────────
function SceneClickHandler() {
  const { setSelected } = useLabStore();

  useEffect(() => {
    const handler = () => setSelected(null);
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') setSelected(null);
    });
  }, [setSelected]);

  return null;
}

// ── Camera Rig ───────────────────────────────────────────────
function CameraRig() {
  const { selectedContainerId, containers } = useLabStore();
  const { camera } = useThree();

  useFrame(() => {
    if (!selectedContainerId) return;
    const target = containers.find(c => c.id === selectedContainerId);
    if (!target) return;

    const targetPos = new THREE.Vector3(
      target.position[0],
      target.position[1] + 0.5,
      target.position[2]
    );
    // Smooth camera focus
    camera.position.lerp(
      new THREE.Vector3(targetPos.x * 0.5, targetPos.y + 1.2, 2.8),
      0.02
    );
  });

  return null;
}

// ── Main Scene Export ────────────────────────────────────────
export default function LabScene() {
  const { containers, tickHeating, tickPour } = useLabStore();

  return (
    <Canvas
      shadows
      gl={{
        antialias: true,
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.1,
        outputColorSpace: THREE.SRGBColorSpace,
      }}
      camera={{ position: [0, 0.8, 3.5], fov: 55, near: 0.01, far: 100 }}
      style={{ width: '100%', height: '100%' }}
    >
      <PerformanceMonitor
        onDecline={() => console.log('Performance decline detected')}
      />
      <AdaptiveDpr pixelated />
      <AdaptiveEvents />

      <Suspense fallback={null}>
        {/* Environment */}
        <Environment preset="warehouse" />
        <LabLighting />
        <LabRoom />
        <LabBench />

        {/* Containers */}
        <Physics gravity={[0, -9.81, 0]} debug={false}>
          {containers.map(container => (
            <Beaker key={container.id} container={container} />
          ))}
        </Physics>

        {/* Effects */}
        <PourStream />
        <HeatHazeEffect />
        <GasParticles />

        {/* Ground shadows */}
        <ContactShadows
          position={[0, -0.79, 0]}
          opacity={0.4}
          scale={8}
          blur={2.4}
          far={1}
          color="#000000"
        />

        <Preload all />
      </Suspense>

      {/* Camera */}
      <PerspectiveCamera makeDefault position={[0, 0.8, 3.5]} fov={55} />
      <OrbitControls
        target={[0, 0, 0]}
        minDistance={1.5}
        maxDistance={6}
        maxPolarAngle={Math.PI / 2.1}
        enableDamping
        dampingFactor={0.05}
      />
      <CameraRig />
      <SceneClickHandler />

      {/* Frame loop */}
      <FrameLoop />
    </Canvas>
  );
}

// ── Frame tick for heating + pouring ────────────────────────
function FrameLoop() {
  const { tickHeating, tickPour } = useLabStore();
  let last = 0;

  useFrame((_, delta) => {
    tickHeating(delta);
    tickPour(delta);
  });

  return null;
}
