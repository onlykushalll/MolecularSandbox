'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Pour Stream Visualizer
// Torricelli's theorem | Sine-wave droplet breakup | Color
// ============================================================

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useLabStore } from '@/lib/store/lab-store';
import { calcPourRate } from '@/lib/chemistry/engine';

const STREAM_SEGMENTS = 20;
const G = 9.81;

export default function PourStream() {
  const { pourStream, containers } = useLabStore();
  const lineRef = useRef<THREE.Line>(null!);
  const dropletRef = useRef<THREE.InstancedMesh>(null!);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const positions = useMemo(
    () => new Float32Array(STREAM_SEGMENTS * 3),
    []
  );

  useFrame(({ clock }) => {
    if (!pourStream || !lineRef.current) return;

    const from = containers.find(c => c.id === pourStream.fromId);
    const to = containers.find(c => c.id === pourStream.toId);
    if (!from || !to) return;

    const t = clock.elapsedTime;

    // Source: lip of the tilted beaker
    const src = new THREE.Vector3(
      from.position[0] + 0.4,
      from.position[1] + 0.5,
      from.position[2]
    );

    // Destination: opening of target beaker
    const dst = new THREE.Vector3(
      to.position[0],
      to.position[1] + 0.6,
      to.position[2]
    );

    // Parabolic stream via Torricelli: h = liquidHeight, v0 = √(2gh)
    const liquidHeightM = (from.volumeML / from.capacityML) * 0.8; // meters
    const v0 = Math.sqrt(2 * G * liquidHeightM);

    // Get the primary color of the source liquid
    const streamColor = from.color;

    for (let i = 0; i < STREAM_SEGMENTS; i++) {
      const s = i / (STREAM_SEGMENTS - 1);

      // Cubic bezier-like interpolation with gravity sag
      const x = src.x + (dst.x - src.x) * s;
      const z = src.z + (dst.z - src.z) * s;

      // Parabolic arc: y = y0 + v0t - 0.5*g*t^2
      // Simplified: sag proportional to s*(1-s)*factor
      const sag = 4 * s * (1 - s) * Math.max(0, src.y - dst.y);
      const y = src.y * (1 - s) + dst.y * s - sag * 0.8;

      // Sine wave distortion (droplet breakup near end)
      const breakup = Math.pow(s, 2.5);
      const wobbleAmp = breakup * 0.04;
      const wx = Math.sin(t * 12 + s * 15) * wobbleAmp;
      const wz = Math.cos(t * 10 + s * 12) * wobbleAmp;

      positions[i * 3 + 0] = x + wx;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z + wz;
    }

    const geom = lineRef.current.geometry;
    const posAttr = geom.attributes.position as THREE.BufferAttribute;
    posAttr.array.set(positions);
    posAttr.needsUpdate = true;

    // Width based on flow rate
    const flowRate = calcPourRate(liquidHeightM);
    const width = Math.min(Math.max(flowRate / 50, 0.01), 0.08);
    (lineRef.current.material as THREE.LineBasicMaterial).linewidth = width;
    (lineRef.current.material as THREE.LineBasicMaterial).color.set(streamColor);

    // Droplets
    if (dropletRef.current) {
      for (let i = 0; i < 8; i++) {
        const phase = (i / 8 + (t * 0.8) % 1);
        const s = phase;
        const x = src.x + (dst.x - src.x) * s;
        const sag = 4 * s * (1 - s) * Math.max(0, src.y - dst.y);
        const y = src.y * (1 - s) + dst.y * s - sag * 0.8;
        const z = src.z + (dst.z - src.z) * s;

        dummy.position.set(x, y, z);
        dummy.scale.setScalar(0.015 + Math.sin(i * 1.7) * 0.008);
        dummy.updateMatrix();
        dropletRef.current.setMatrixAt(i, dummy.matrix);
      }
      dropletRef.current.instanceMatrix.needsUpdate = true;

      // Color
      const mat = dropletRef.current.material as THREE.MeshBasicMaterial;
      mat.color.set(streamColor);
    }
  });

  if (!pourStream) return null;

  const from = containers.find(c => c.id === pourStream.fromId);
  const streamColor = from?.color ?? '#4488ff';

  return (
    <group>
      {/* Continuous stream */}
      <line_ ref={lineRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            array={positions}
            count={STREAM_SEGMENTS}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial
          color={streamColor}
          transparent
          opacity={0.85}
          linewidth={2}
        />
      </line_>

      {/* Droplets near the end */}
      <instancedMesh ref={dropletRef} args={[undefined, undefined, 8]}>
        <sphereGeometry args={[1, 6, 6]} />
        <meshBasicMaterial
          color={streamColor}
          transparent
          opacity={0.7}
        />
      </instancedMesh>
    </group>
  );
}
