'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Lab Journal
// Auto-logging | Scientific notation | Export
// ============================================================

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLabStore } from '@/lib/store/lab-store';
import type { JournalEntry } from '@/lib/chemistry/types';

const TYPE_CONFIG: Record<JournalEntry['type'], { icon: string; color: string; bg: string }> = {
  reaction: { icon: '⚡', color: '#f97316', bg: 'rgba(249,115,22,0.08)' },
  observation: { icon: '👁', color: '#60a5fa', bg: 'rgba(96,165,250,0.06)' },
  measurement: { icon: '📐', color: '#a78bfa', bg: 'rgba(167,139,250,0.06)' },
  safety: { icon: '⚠️', color: '#fbbf24', bg: 'rgba(251,191,36,0.06)' },
  error: { icon: '❌', color: '#f87171', bg: 'rgba(248,113,113,0.06)' },
};

function JournalEntryCard({ entry }: { entry: JournalEntry }) {
  const config = TYPE_CONFIG[entry.type];
  const time = new Date(entry.timestamp);
  const timeStr = `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}:${time.getSeconds().toString().padStart(2, '0')}`;

  return (
    <motion.div
      initial={{ opacity: 0, x: 20, height: 0 }}
      animate={{ opacity: 1, x: 0, height: 'auto' }}
      exit={{ opacity: 0, x: -20 }}
      style={{
        background: config.bg,
        border: `1px solid ${config.color}22`,
        borderLeft: `3px solid ${config.color}`,
        borderRadius: '6px',
        padding: '8px 10px',
        marginBottom: '5px',
      }}
    >
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '3px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <span style={{ fontSize: '11px' }}>{config.icon}</span>
          <span style={{
            fontSize: '10px',
            color: config.color,
            fontFamily: '"Space Mono", monospace',
            fontWeight: 700,
            letterSpacing: '0.05em',
          }}>
            {entry.title}
          </span>
        </div>
        <span style={{
          fontSize: '8px',
          color: '#334155',
          fontFamily: '"Space Mono", monospace',
        }}>
          {timeStr}
        </span>
      </div>

      <p style={{
        fontSize: '9px',
        color: '#64748b',
        lineHeight: 1.6,
        margin: 0,
        fontFamily: 'monospace',
      }}>
        {entry.body}
      </p>
    </motion.div>
  );
}

export default function LabJournal() {
  const { journal, clearJournal, isPanelOpen, togglePanel } = useLabStore();
  const [filter, setFilter] = useState<JournalEntry['type'] | 'all'>('all');
  const isOpen = isPanelOpen['journal'];

  const filtered = filter === 'all'
    ? journal
    : journal.filter(e => e.type === filter);

  const handleExport = () => {
    const text = journal.map(e =>
      `[${new Date(e.timestamp).toISOString()}] [${e.type.toUpperCase()}] ${e.title}\n${e.body}\n`
    ).join('\n');

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lab-journal-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      {/* Journal toggle button */}
      <button
        onClick={() => togglePanel('journal')}
        style={{
          position: 'absolute',
          bottom: '80px',
          left: '50%',
          transform: 'translateX(-50%)',
          background: isOpen ? 'rgba(34,197,94,0.15)' : 'rgba(10,14,20,0.88)',
          border: `1px solid ${isOpen ? 'rgba(34,197,94,0.4)' : 'rgba(255,255,255,0.1)'}`,
          borderRadius: '20px',
          padding: '8px 16px',
          color: '#22c55e',
          fontSize: '11px',
          fontFamily: '"Space Mono", monospace',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          backdropFilter: 'blur(10px)',
          zIndex: 25,
          letterSpacing: '0.06em',
        }}
      >
        📔 LAB JOURNAL
        {journal.length > 0 && (
          <span style={{
            background: '#22c55e',
            color: '#000',
            borderRadius: '10px',
            padding: '1px 5px',
            fontSize: '8px',
            fontWeight: 700,
          }}>
            {journal.length}
          </span>
        )}
      </button>

      {/* Journal drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            style={{
              position: 'absolute',
              bottom: 0,
              left: '260px',
              right: '240px',
              height: '45vh',
              background: 'rgba(8,12,18,0.95)',
              backdropFilter: 'blur(20px)',
              borderTop: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '16px 16px 0 0',
              display: 'flex',
              flexDirection: 'column',
              zIndex: 20,
              boxShadow: '0 -8px 32px rgba(0,0,0,0.5)',
            }}
          >
            {/* Header */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '12px 16px',
              borderBottom: '1px solid rgba(255,255,255,0.06)',
            }}>
              <div style={{
                fontFamily: '"Space Mono", monospace',
                fontSize: '12px',
                color: '#22c55e',
                fontWeight: 700,
                letterSpacing: '0.1em',
              }}>
                📔 LAB JOURNAL
              </div>

              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                {/* Filter buttons */}
                {(['all', 'reaction', 'observation', 'safety'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    style={{
                      fontSize: '9px',
                      fontFamily: '"Space Mono", monospace',
                      padding: '3px 7px',
                      borderRadius: '4px',
                      border: `1px solid ${filter === f ? '#22c55e44' : 'rgba(255,255,255,0.06)'}`,
                      background: filter === f ? 'rgba(34,197,94,0.12)' : 'transparent',
                      color: filter === f ? '#22c55e' : '#334155',
                      cursor: 'pointer',
                    }}
                  >
                    {f.toUpperCase()}
                  </button>
                ))}

                <button
                  onClick={handleExport}
                  style={{
                    fontSize: '9px',
                    fontFamily: '"Space Mono", monospace',
                    padding: '3px 8px',
                    borderRadius: '4px',
                    border: '1px solid rgba(96,165,250,0.3)',
                    background: 'rgba(96,165,250,0.08)',
                    color: '#60a5fa',
                    cursor: 'pointer',
                  }}
                >
                  ↓ EXPORT
                </button>

                <button
                  onClick={clearJournal}
                  style={{
                    fontSize: '9px',
                    fontFamily: '"Space Mono", monospace',
                    padding: '3px 8px',
                    borderRadius: '4px',
                    border: '1px solid rgba(248,113,113,0.3)',
                    background: 'rgba(248,113,113,0.06)',
                    color: '#f87171',
                    cursor: 'pointer',
                  }}
                >
                  CLEAR
                </button>
              </div>
            </div>

            {/* Entries */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '10px 14px',
              scrollbarWidth: 'thin',
              scrollbarColor: '#22c55e22 transparent',
            }}>
              {filtered.length === 0 ? (
                <div style={{
                  textAlign: 'center',
                  color: '#1e293b',
                  fontSize: '12px',
                  fontFamily: '"Space Mono", monospace',
                  marginTop: '30px',
                }}>
                  No entries yet.<br />
                  <span style={{ fontSize: '10px', color: '#0f172a' }}>
                    Add chemicals to beakers to start logging.
                  </span>
                </div>
              ) : (
                <AnimatePresence>
                  {[...filtered].reverse().map(entry => (
                    <JournalEntryCard key={entry.id} entry={entry} />
                  ))}
                </AnimatePresence>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
