'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Beaker Component
// Physics-accurate glass + liquid rendering with diegetic HUD
// ============================================================

import { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, useCursor } from '@react-three/drei';
import * as THREE from 'three';
import { useLabStore } from '@/lib/store/lab-store';
import type { ContainerState } from '@/lib/chemistry/types';
import { CHEMICAL_MAP } from '@/lib/chemistry/data';
import '../lab/LiquidMaterial';
import '../lab/GlassMaterial';

interface BeakerProps {
  container: ContainerState;
}

// Build beaker geometry procedurally
function makeBeakerGeometry(type: ContainerState['type']): {
  outer: THREE.CylinderGeometry;
  inner: THREE.CylinderGeometry;
  liquidCyl: THREE.CylinderGeometry;
} {
  const specs: Record<ContainerState['type'], { rt: number; rb: number; h: number }> = {
    beaker: { rt: 0.42, rb: 0.38, h: 1.0 },
    flask: { rt: 0.18, rb: 0.52, h: 1.2 },
    test_tube: { rt: 0.15, rb: 0.15, h: 1.4 },
    graduated_cylinder: { rt: 0.18, rb: 0.18, h: 1.6 },
    burette: { rt: 0.1, rb: 0.1, h: 2.0 },
  };

  const s = specs[type] ?? specs.beaker;
  const wallThickness = 0.03;

  return {
    outer: new THREE.CylinderGeometry(s.rt, s.rb, s.h, 32, 1, true),
    inner: new THREE.CylinderGeometry(s.rt - wallThickness, s.rb - wallThickness, s.h, 32, 1, true),
    liquidCyl: new THREE.CylinderGeometry(
      s.rt - wallThickness - 0.01,
      s.rb - wallThickness - 0.01,
      s.h,
      32, 4, false
    ),
  };
}

export default function Beaker({ container }: BeakerProps) {
  const groupRef = useRef<THREE.Group>(null!);
  const liquidMatRef = useRef<THREE.ShaderMaterial>(null!);
  const glassMatRef = useRef<THREE.ShaderMaterial>(null!);

  const {
    selectedContainerId, hoveredContainerId,
    setSelected, setHovered,
    addChemicalToContainer, draggingChemical,
    toolMode,
  } = useLabStore();

  const isSelected = selectedContainerId === container.id;
  const isHovered = hoveredContainerId === container.id;

  useCursor(isHovered);

  const { outer, inner, liquidCyl } = useMemo(
    () => makeBeakerGeometry(container.type),
    [container.type]
  );

  const liquidColor = useMemo(
    () => new THREE.Color(container.color),
    [container.color]
  );

  const fillAmount = container.capacityML > 0
    ? container.volumeML / container.capacityML
    : 0;

  // Viscosity from primary chemical
  const viscosity = useMemo(() => {
    if (container.contents.length === 0) return 0.1;
    const primary = container.contents.reduce((a, b) =>
      a.massGrams > b.massGrams ? a : b
    );
    const chem = CHEMICAL_MAP.get(primary.formula);
    return chem ? Math.min(chem.viscosity / 30, 1) : 0.1;
  }, [container.contents]);

  // Condensation: hot liquid + cool glass
  const condensation = Math.max(0, Math.min(1,
    (container.temperatureC - 25) / 80
  ));

  // Per-frame shader uniform updates
  useFrame((state) => {
    const t = state.clock.elapsedTime;

    if (liquidMatRef.current) {
      liquidMatRef.current.uniforms.uTime.value = t;
      liquidMatRef.current.uniforms.uFillAmount.value = fillAmount;
      liquidMatRef.current.uniforms.uColor.value = liquidColor;
      liquidMatRef.current.uniforms.uViscosity.value = viscosity;
      liquidMatRef.current.uniforms.uIsStirring.value = container.isStirring ? 1 : 0;
      liquidMatRef.current.uniforms.uStirSpeed.value = container.isStirring ? 1.5 : 0;
    }

    if (glassMatRef.current) {
      glassMatRef.current.uniforms.uTime.value = t;
      glassMatRef.current.uniforms.uCondensation.value = condensation;
      glassMatRef.current.uniforms.uCrackLevel.value = container.isBroken ? 1 : 0;
    }

    // Gentle floating animation
    if (groupRef.current) {
      groupRef.current.position.y =
        container.position[1] +
        Math.sin(t * 0.3 + container.id.charCodeAt(0)) * 0.003;
    }
  });

  const handleClick = (e: THREE.Event) => {
    e.stopPropagation();
    if (draggingChemical && toolMode === 'select') {
      // Drop chemical into container
      addChemicalToContainer(container.id, draggingChemical, 10);
      useLabStore.getState().setDraggingChemical(null);
    } else {
      setSelected(isSelected ? null : container.id);
    }
  };

  const handlePointerOver = (e: THREE.Event) => {
    e.stopPropagation();
    setHovered(container.id);
  };

  const handlePointerOut = () => setHovered(null);

  // Temperature heat haze color
  const tempColor = container.temperatureC > 60
    ? `rgba(255,${Math.max(0, 140 - (container.temperatureC - 60) * 2)},0,0.8)`
    : '#22c55e';

  return (
    <group
      ref={groupRef}
      position={container.position}
      rotation={container.rotation}
      onClick={handleClick}
      onPointerOver={handlePointerOver}
      onPointerOut={handlePointerOut}
    >
      {/* ── Outer glass wall ── */}
      <mesh geometry={outer} renderOrder={1}>
        {/* @ts-ignore */}
        <glassShaderMaterial
          ref={glassMatRef}
          transparent
          depthWrite={false}
          side={THREE.DoubleSide}
          uIOR={1.517}
          uOpacity={0.12}
          uCondensation={condensation}
          uCrackLevel={container.isBroken ? 1 : 0}
        />
      </mesh>

      {/* ── Glass bottom disc ── */}
      <mesh position={[0, -0.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.35, 32]} />
        {/* @ts-ignore */}
        <glassShaderMaterial
          transparent
          depthWrite={false}
          uIOR={1.517}
          uOpacity={0.2}
        />
      </mesh>

      {/* ── Liquid volume ── */}
      {fillAmount > 0.01 && (
        <mesh geometry={liquidCyl} renderOrder={2}>
          {/* @ts-ignore */}
          <liquidShaderMaterial
            ref={liquidMatRef}
            transparent
            depthWrite={false}
            side={THREE.FrontSide}
            uFillAmount={fillAmount}
            uColor={liquidColor}
            uViscosity={viscosity}
            uAbsorptionCoeff={0.8}
          />
        </mesh>
      )}

      {/* ── Gas bubbles (simple spheres) ── */}
      {container.gasVolumeMol > 0.001 && (
        <BubbleSystem count={Math.min(Math.round(container.gasVolumeMol * 20), 30)} />
      )}

      {/* ── Selection ring ── */}
      {(isSelected || isHovered) && (
        <mesh position={[0, -0.52, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.38, 0.44, 32]} />
          <meshBasicMaterial
            color={isSelected ? '#22c55e' : '#60a5fa'}
            transparent
            opacity={0.7}
          />
        </mesh>
      )}

      {/* ── Diegetic HUD Label ── */}
      <Html
        position={[0, 0.85, 0]}
        center
        distanceFactor={4}
        occlude
        style={{ pointerEvents: 'none' }}
      >
        <BeakerHUD container={container} tempColor={tempColor} />
      </Html>

      {/* ── Heat glow when heating ── */}
      {container.isHeating && (
        <pointLight
          position={[0, -0.6, 0]}
          color="#ff6600"
          intensity={1.5}
          distance={1.5}
        />
      )}
    </group>
  );
}

// ── Gas bubble animation ─────────────────────────────────────
function BubbleSystem({ count }: { count: number }) {
  const meshRef = useRef<THREE.InstancedMesh>(null!);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const t = clock.elapsedTime;
    for (let i = 0; i < count; i++) {
      const phase = (i / count) * Math.PI * 2;
      const speed = 0.3 + (i % 5) * 0.1;
      const x = Math.sin(phase + i * 0.7) * 0.2;
      const y = -0.4 + ((t * speed + i * 0.3) % 0.9);
      const z = Math.cos(phase + i * 0.5) * 0.2;
      const scale = 0.015 + (i % 3) * 0.008;

      dummy.position.set(x, y, z);
      dummy.scale.setScalar(scale);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 8, 8]} />
      <meshPhysicalMaterial
        color="#c8e6ff"
        transparent
        opacity={0.4}
        roughness={0}
        metalness={0}
        transmission={0.9}
      />
    </instancedMesh>
  );
}

// ── Diegetic HUD (holographic label) ────────────────────────
function BeakerHUD({
  container,
  tempColor,
}: {
  container: ContainerState;
  tempColor: string;
}) {
  const primaryChemical = container.contents.length > 0
    ? container.contents.reduce((a, b) => a.massGrams > b.massGrams ? a : b)
    : null;
  const chemData = primaryChemical ? CHEMICAL_MAP.get(primaryChemical.formula) : null;

  return (
    <div
      style={{
        fontFamily: '"Space Mono", monospace',
        fontSize: '10px',
        color: '#00ff88',
        background: 'rgba(0,20,10,0.75)',
        border: '1px solid rgba(0,255,136,0.3)',
        borderRadius: '6px',
        padding: '6px 10px',
        minWidth: '120px',
        backdropFilter: 'blur(8px)',
        boxShadow: '0 0 12px rgba(0,255,136,0.2), inset 0 0 8px rgba(0,255,136,0.05)',
        textAlign: 'center',
        userSelect: 'none',
        lineHeight: '1.6',
        letterSpacing: '0.03em',
      }}
    >
      <div style={{ color: '#aaffcc', fontSize: '9px', marginBottom: '2px', opacity: 0.7 }}>
        {container.type.toUpperCase()}
      </div>

      {chemData ? (
        <div style={{ color: '#ffffff', fontWeight: 'bold', fontSize: '11px' }}>
          {chemData.formula}
        </div>
      ) : (
        <div style={{ color: '#555', fontSize: '10px' }}>EMPTY</div>
      )}

      {container.volumeML > 0 && (
        <>
          <div style={{ marginTop: '3px' }}>
            <span style={{ color: '#88ccff' }}>{container.volumeML.toFixed(1)}</span>
            <span style={{ color: '#456', fontSize: '8px' }}> mL</span>
          </div>
          <div style={{ color: tempColor, fontSize: '9px' }}>
            {container.temperatureC.toFixed(1)}°C
          </div>
          <div style={{
            fontSize: '8px',
            color: container.pH < 7 ? '#ff9966' : container.pH > 7 ? '#66aaff' : '#aaffcc',
          }}>
            pH {container.pH.toFixed(1)}
          </div>
        </>
      )}

      {container.isHeating && (
        <div style={{ color: '#ff6600', fontSize: '8px', animation: 'pulse 1s infinite' }}>
          🔥 HEATING
        </div>
      )}
      {container.gasVolumeMol > 0.001 && (
        <div style={{ color: '#ffee00', fontSize: '8px' }}>
          ⚗ GAS EVOLVING
        </div>
      )}
    </div>
  );
}
