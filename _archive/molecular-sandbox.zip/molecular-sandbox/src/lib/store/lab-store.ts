'use client';
// ============================================================
// THE MOLECULAR SANDBOX — Zustand Lab Store
// ============================================================

import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import type { ContainerState, JournalEntry, PourStream, ReactionEvent, MixtureComponent } from '../chemistry/types';
import { solveReaction, applyReactionToContainer, mixColors, estimatePH, calcPourRate, getMoles } from '../chemistry/engine';
import { CHEMICAL_MAP } from '../chemistry/data';
import { v4 as uuid } from 'uuid';

export type ToolMode = 'select' | 'pour' | 'heat' | 'stir' | 'measure';
export type PPEItem = 'goggles' | 'gloves' | 'lab_coat' | 'face_shield';

interface LabStore {
  // ── Containers ───────────────────────────────────────────
  containers: ContainerState[];
  addContainer: (type: ContainerState['type'], position: [number, number, number]) => void;
  removeContainer: (id: string) => void;
  updateContainer: (id: string, patch: Partial<ContainerState>) => void;

  // ── Chemical addition ────────────────────────────────────
  addChemicalToContainer: (containerId: string, formula: string, massGrams: number) => void;
  pourBetweenContainers: (fromId: string, toId: string, volumeML: number) => void;

  // ── Reactions ────────────────────────────────────────────
  activeReactions: ReactionEvent[];
  triggerReaction: (containerId: string) => void;
  checkAllContainers: () => void;

  // ── Selection & Interaction ──────────────────────────────
  selectedContainerId: string | null;
  hoveredContainerId: string | null;
  setSelected: (id: string | null) => void;
  setHovered: (id: string | null) => void;

  // ── Pour stream ──────────────────────────────────────────
  pourStream: PourStream | null;
  startPour: (fromId: string, toId: string) => void;
  stopPour: () => void;
  tickPour: (deltaSeconds: number) => void;

  // ── Tool mode ────────────────────────────────────────────
  toolMode: ToolMode;
  setToolMode: (mode: ToolMode) => void;

  // ── PPE system ───────────────────────────────────────────
  equippedPPE: Set<PPEItem>;
  equipPPE: (item: PPEItem) => void;
  removePPE: (item: PPEItem) => void;
  isPPEComplete: () => boolean;

  // ── Safety ───────────────────────────────────────────────
  isInsideFumeHood: boolean;
  setInsideFumeHood: (v: boolean) => void;
  toxicityLevel: number; // 0-1
  safetyViolations: string[];
  addSafetyViolation: (msg: string) => void;

  // ── Journal ──────────────────────────────────────────────
  journal: JournalEntry[];
  addJournalEntry: (entry: Omit<JournalEntry, 'id' | 'timestamp'>) => void;
  clearJournal: () => void;

  // ── UI state ─────────────────────────────────────────────
  isPanelOpen: Record<string, boolean>;
  togglePanel: (panel: string) => void;
  ambientTempC: number;
  unlimitedMode: boolean;
  setUnlimitedMode: (v: boolean) => void;

  // ── Drag-drop ────────────────────────────────────────────
  draggingChemical: string | null;
  setDraggingChemical: (formula: string | null) => void;

  // ── Heating ──────────────────────────────────────────────
  tickHeating: (deltaSeconds: number) => void;
}

const BEAKER_CAPACITY: Record<ContainerState['type'], number> = {
  beaker: 250,
  flask: 500,
  test_tube: 20,
  graduated_cylinder: 100,
  burette: 50,
};

function makeContainer(
  type: ContainerState['type'],
  position: [number, number, number]
): ContainerState {
  return {
    id: uuid(),
    type,
    capacityML: BEAKER_CAPACITY[type],
    volumeML: 0,
    contents: [],
    temperatureC: 25,
    pressureKPa: 101.325,
    isHeating: false,
    isStirring: false,
    isClosed: false,
    isBroken: false,
    position,
    rotation: [0, 0, 0],
    color: '#c8e6ff',
    pH: 7,
    gasVolumeMol: 0,
  };
}

export const useLabStore = create<LabStore>()(
  subscribeWithSelector((set, get) => ({
    // ── Containers ───────────────────────────────────────
    containers: [
      { ...makeContainer('beaker', [-0.8, 0, 0]), id: 'beaker-1' },
      { ...makeContainer('beaker', [0.0, 0, 0]), id: 'beaker-2' },
      { ...makeContainer('beaker', [0.8, 0, 0]), id: 'beaker-3' },
    ],

    addContainer: (type, position) =>
      set(s => ({ containers: [...s.containers, makeContainer(type, position)] })),

    removeContainer: (id) =>
      set(s => ({ containers: s.containers.filter(c => c.id !== id) })),

    updateContainer: (id, patch) =>
      set(s => ({
        containers: s.containers.map(c => c.id === id ? { ...c, ...patch } : c),
      })),

    // ── Chemical addition ────────────────────────────────
    addChemicalToContainer: (containerId, formula, massGrams) => {
      const { containers, triggerReaction, addJournalEntry } = get();
      const chem = CHEMICAL_MAP.get(formula);
      if (!chem) return;

      const container = containers.find(c => c.id === containerId);
      if (!container) return;

      // Volume approximation: mass / density for liquids
      const addedVolume = chem.stateAtSTP === 'liquid'
        ? massGrams / chem.density
        : chem.stateAtSTP === 'solid' ? 0 : 0; // solids add mass, not volume

      if (container.volumeML + addedVolume > container.capacityML) {
        get().addSafetyViolation(`Overflow risk in ${container.type}!`);
        return;
      }

      const existing = container.contents.findIndex(c => c.formula === formula);
      let newContents: MixtureComponent[];

      if (existing !== -1) {
        newContents = container.contents.map((c, i) =>
          i === existing ? { ...c, massGrams: c.massGrams + massGrams } : c
        );
      } else {
        newContents = [...container.contents, {
          formula,
          massGrams,
          state: chem.stateAtSTP,
        }];
      }

      const newColor = mixColors(newContents);
      const newVolume = container.volumeML + addedVolume;
      const newPH = estimatePH(newContents, newVolume);

      set(s => ({
        containers: s.containers.map(c =>
          c.id === containerId
            ? { ...c, contents: newContents, volumeML: newVolume, color: newColor, pH: newPH }
            : c
        ),
      }));

      addJournalEntry({
        type: 'observation',
        title: `Added ${formula}`,
        body: `Added ${massGrams.toFixed(2)}g of ${chem.name} (${chem.formula}) to ${container.type}. Volume: ${newVolume.toFixed(1)}mL. pH: ${newPH.toFixed(2)}`,
      });

      // Check for reactions after a brief delay
      setTimeout(() => triggerReaction(containerId), 100);
    },

    pourBetweenContainers: (fromId, toId, volumeML) => {
      const { containers } = get();
      const from = containers.find(c => c.id === fromId);
      const to = containers.find(c => c.id === toId);
      if (!from || !to) return;

      const fraction = volumeML / Math.max(from.volumeML, 0.001);
      const transferredContents: MixtureComponent[] = from.contents.map(comp => ({
        ...comp,
        massGrams: comp.massGrams * fraction,
      }));

      const remainingContents: MixtureComponent[] = from.contents.map(comp => ({
        ...comp,
        massGrams: comp.massGrams * (1 - fraction),
      })).filter(c => c.massGrams > 0.001);

      // Merge into destination
      let newToContents = [...to.contents];
      for (const tc of transferredContents) {
        const idx = newToContents.findIndex(c => c.formula === tc.formula);
        if (idx !== -1) {
          newToContents[idx] = { ...newToContents[idx], massGrams: newToContents[idx].massGrams + tc.massGrams };
        } else {
          newToContents.push(tc);
        }
      }

      const newToVolume = Math.min(to.volumeML + volumeML, to.capacityML);
      const newFromVolume = Math.max(from.volumeML - volumeML, 0);

      set(s => ({
        containers: s.containers.map(c => {
          if (c.id === fromId) return {
            ...c,
            contents: remainingContents,
            volumeML: newFromVolume,
            color: mixColors(remainingContents),
            pH: estimatePH(remainingContents, newFromVolume),
          };
          if (c.id === toId) return {
            ...c,
            contents: newToContents,
            volumeML: newToVolume,
            color: mixColors(newToContents),
            pH: estimatePH(newToContents, newToVolume),
          };
          return c;
        }),
      }));

      setTimeout(() => get().triggerReaction(toId), 100);
    },

    // ── Reactions ────────────────────────────────────────
    activeReactions: [],

    triggerReaction: (containerId) => {
      const { containers, addJournalEntry } = get();
      const container = containers.find(c => c.id === containerId);
      if (!container || container.contents.length < 2) return;

      const result = solveReaction(container);
      if (!result.canReact) return;

      const updated = applyReactionToContainer(container, result);

      const event: ReactionEvent = {
        id: uuid(),
        timestamp: Date.now(),
        containerId,
        reactionId: result.reactionId!,
        reactionName: result.reactionId!,
        equation: '',
        limitingReagent: result.limitingReagent!,
        molesReacted: result.molesReacted!,
        deltaHTotal: result.deltaHTotal,
        temperatureChange: result.temperatureChange,
        producedGas: result.gasProduced?.formula,
        producedPrecipitate: result.precipitateFormed?.formula,
        newTemperatureC: updated.temperatureC,
      };

      set(s => ({
        containers: s.containers.map(c => c.id === containerId ? updated : c),
        activeReactions: [...s.activeReactions.slice(-9), event],
      }));

      const sign = result.deltaHTotal < 0 ? '⬇️ Exothermic' : '⬆️ Endothermic';
      addJournalEntry({
        type: 'reaction',
        title: `Reaction detected`,
        body: `${sign} | ΔH = ${result.deltaHTotal.toFixed(2)} kJ | ΔT = ${result.temperatureChange > 0 ? '+' : ''}${result.temperatureChange.toFixed(1)}°C | Limiting: ${result.limitingReagent}${result.gasProduced ? ` | Gas: ${result.gasProduced.formula}` : ''}${result.precipitateFormed ? ` | Precipitate: ${result.precipitateFormed.formula}` : ''}`,
        data: { reactionId: result.reactionId, event },
      });

      // Safety — toxic gas outside fume hood
      if (result.gasProduced) {
        const gasChem = CHEMICAL_MAP.get(result.gasProduced.formula);
        if (gasChem?.isToxic && !get().isInsideFumeHood) {
          get().addSafetyViolation(`⚠️ Toxic gas (${result.gasProduced.formula}) released outside fume hood!`);
        }
      }

      // Pressure explosion check
      if (container.isClosed && updated.gasVolumeMol > 0.1) {
        get().addSafetyViolation(`💥 Pressure buildup in closed container!`);
      }
    },

    checkAllContainers: () => {
      const { containers, triggerReaction } = get();
      containers.forEach(c => triggerReaction(c.id));
    },

    // ── Selection ────────────────────────────────────────
    selectedContainerId: null,
    hoveredContainerId: null,
    setSelected: (id) => set({ selectedContainerId: id }),
    setHovered: (id) => set({ hoveredContainerId: id }),

    // ── Pour stream ──────────────────────────────────────
    pourStream: null,

    startPour: (fromId, toId) => {
      const from = get().containers.find(c => c.id === fromId);
      if (!from || from.volumeML <= 0) return;
      set({
        pourStream: { fromId, toId, flowRateMLperS: 10, tiltAngle: 45 },
      });
    },

    stopPour: () => set({ pourStream: null }),

    tickPour: (deltaSeconds) => {
      const { pourStream, pourBetweenContainers } = get();
      if (!pourStream) return;
      const transferred = pourStream.flowRateMLperS * deltaSeconds;
      pourBetweenContainers(pourStream.fromId, pourStream.toId, transferred);
    },

    // ── Tool mode ────────────────────────────────────────
    toolMode: 'select',
    setToolMode: (mode) => set({ toolMode: mode }),

    // ── PPE ──────────────────────────────────────────────
    equippedPPE: new Set(),

    equipPPE: (item) =>
      set(s => {
        const next = new Set(s.equippedPPE);
        next.add(item);
        return { equippedPPE: next };
      }),

    removePPE: (item) =>
      set(s => {
        const next = new Set(s.equippedPPE);
        next.delete(item);
        return { equippedPPE: next };
      }),

    isPPEComplete: () => {
      const { equippedPPE } = get();
      return equippedPPE.has('goggles') && equippedPPE.has('gloves');
    },

    // ── Safety ───────────────────────────────────────────
    isInsideFumeHood: false,
    setInsideFumeHood: (v) => set({ isInsideFumeHood: v }),
    toxicityLevel: 0,
    safetyViolations: [],

    addSafetyViolation: (msg) => {
      get().addJournalEntry({ type: 'safety', title: 'Safety Alert', body: msg });
      set(s => ({
        safetyViolations: [...s.safetyViolations.slice(-4), msg],
      }));
    },

    // ── Journal ──────────────────────────────────────────
    journal: [],

    addJournalEntry: (entry) =>
      set(s => ({
        journal: [
          ...s.journal,
          { ...entry, id: uuid(), timestamp: Date.now() },
        ].slice(-100), // keep last 100 entries
      })),

    clearJournal: () => set({ journal: [] }),

    // ── UI ───────────────────────────────────────────────
    isPanelOpen: {
      chemicals: true,
      journal: false,
      instruments: true,
      safety: false,
    },

    togglePanel: (panel) =>
      set(s => ({
        isPanelOpen: { ...s.isPanelOpen, [panel]: !s.isPanelOpen[panel] },
      })),

    ambientTempC: 22,
    unlimitedMode: true,
    setUnlimitedMode: (v) => set({ unlimitedMode: v }),

    // ── Drag ─────────────────────────────────────────────
    draggingChemical: null,
    setDraggingChemical: (formula) => set({ draggingChemical: formula }),

    // ── Heating tick ─────────────────────────────────────
    tickHeating: (deltaSeconds) => {
      set(s => ({
        containers: s.containers.map(c => {
          if (!c.isHeating) return c;
          const heatRate = 5; // °C per second on hotplate
          return { ...c, temperatureC: Math.min(c.temperatureC + heatRate * deltaSeconds, 500) };
        }),
      }));
    },
  }))
);
