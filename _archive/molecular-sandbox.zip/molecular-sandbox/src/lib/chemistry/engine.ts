// ============================================================
// THE MOLECULAR SANDBOX — Stoichiometry Engine
// Pure TypeScript. Zero side effects. Fully deterministic.
// ============================================================

import type {
  ChemicalData, ReactionData, MixtureComponent,
  StoichiometryResult, ContainerState, GasState
} from './types';
import { CHEMICAL_MAP, REACTIONS, REACTION_LOOKUP } from './data';

const R_GAS = 8.314; // J/(mol·K) — universal gas constant
const G = 9.81;      // m/s² — gravitational acceleration

// ── Mole / Mass helpers ──────────────────────────────────────
export function getMoles(massGrams: number, formula: string): number {
  const chem = CHEMICAL_MAP.get(formula);
  if (!chem || chem.molarMass <= 0) return 0;
  return massGrams / chem.molarMass;
}

export function getMassFromMoles(moles: number, formula: string): number {
  const chem = CHEMICAL_MAP.get(formula);
  if (!chem) return 0;
  return moles * chem.molarMass;
}

export function getConcentration(massGrams: number, formula: string, volumeML: number): number {
  if (volumeML <= 0) return 0;
  const moles = getMoles(massGrams, formula);
  return moles / (volumeML / 1000); // mol/L
}

// ── Reaction Finder ──────────────────────────────────────────
export function findReaction(contents: MixtureComponent[]): ReactionData | null {
  const formulas = contents.map(c => c.formula);

  for (const rxn of REACTIONS) {
    const required = rxn.reactants.map(r => r.formula);
    const allPresent = required.every(f => formulas.includes(f));
    if (allPresent) return rxn;
  }
  return null;
}

// ── Limiting Reagent ─────────────────────────────────────────
function findLimitingReagent(
  contents: MixtureComponent[],
  reaction: ReactionData
): { formula: string; limitingMoles: number } | null {
  let minRatio = Infinity;
  let limitingFormula = '';

  for (const reactant of reaction.reactants) {
    const component = contents.find(c => c.formula === reactant.formula);
    if (!component) return null;
    const moles = getMoles(component.massGrams, reactant.formula);
    const ratio = moles / reactant.coefficient;
    if (ratio < minRatio) {
      minRatio = ratio;
      limitingFormula = reactant.formula;
    }
  }

  return { formula: limitingFormula, limitingMoles: minRatio };
}

// ── Temperature Change (ΔT = -ΔH·n / (m·c)) ─────────────────
export function calcTemperatureChange(
  deltaHkJ: number,
  moles: number,
  totalMassGrams: number,
  avgSpecificHeat: number
): number {
  if (totalMassGrams <= 0 || avgSpecificHeat <= 0) return 0;
  // ΔH in kJ/mol → convert to J; sign flip because exothermic releases heat into mixture
  return (-deltaHkJ * moles * 1000) / (totalMassGrams * avgSpecificHeat);
}

// ── Average Specific Heat of mixture ────────────────────────
export function avgSpecificHeat(contents: MixtureComponent[]): number {
  let totalMass = 0;
  let weightedHeat = 0;
  for (const comp of contents) {
    const chem = CHEMICAL_MAP.get(comp.formula);
    if (!chem) continue;
    totalMass += comp.massGrams;
    weightedHeat += comp.massGrams * chem.specificHeatCapacity;
  }
  if (totalMass <= 0) return 4.184;
  return weightedHeat / totalMass;
}

// ── pH Estimation ────────────────────────────────────────────
export function estimatePH(contents: MixtureComponent[], volumeML: number): number {
  if (volumeML <= 0 || contents.length === 0) return 7;

  let hMoles = 0;
  let ohMoles = 0;

  for (const comp of contents) {
    const chem = CHEMICAL_MAP.get(comp.formula);
    if (!chem) continue;
    const moles = getMoles(comp.massGrams, comp.formula);

    if (chem.pKa !== undefined && chem.pKa < 3) {
      // Strong acid — fully dissociates
      hMoles += moles;
    } else if (chem.pKa !== undefined && chem.pKa >= 3 && chem.pKa <= 12) {
      // Weak acid — partial dissociation via Ka
      const Ka = Math.pow(10, -chem.pKa);
      const C = moles / (volumeML / 1000);
      hMoles += Math.sqrt(Ka * C) * (volumeML / 1000);
    }

    if (chem.pKb !== undefined && chem.pKb < 1) {
      // Strong base — fully dissociates
      ohMoles += moles;
    } else if (chem.pKb !== undefined && chem.pKb >= 1 && chem.pKb <= 10) {
      const Kb = Math.pow(10, -chem.pKb);
      const C = moles / (volumeML / 1000);
      ohMoles += Math.sqrt(Kb * C) * (volumeML / 1000);
    }
  }

  const netH = hMoles - ohMoles;
  const vol = volumeML / 1000;

  if (Math.abs(netH) < 1e-14) return 7;
  if (netH > 0) {
    const pH = -Math.log10(netH / vol);
    return Math.max(0, Math.min(14, pH));
  } else {
    const pOH = -Math.log10(-netH / vol);
    return Math.max(0, Math.min(14, 14 - pOH));
  }
}

// ── Liquid Color (Beer-Lambert + additive mixing) ────────────
export function mixColors(contents: MixtureComponent[]): string {
  if (contents.length === 0) return '#c8e6ff';

  let r = 0, g = 0, b = 0, totalMass = 0;

  for (const comp of contents) {
    const chem = CHEMICAL_MAP.get(comp.formula);
    if (!chem || comp.massGrams <= 0) continue;
    const hex = chem.hexColor.replace('#', '');
    const cr = parseInt(hex.substring(0, 2), 16);
    const cg = parseInt(hex.substring(2, 4), 16);
    const cb = parseInt(hex.substring(4, 6), 16);

    // Weight by mass for Beer-Lambert approximation
    r += cr * comp.massGrams;
    g += cg * comp.massGrams;
    b += cb * comp.massGrams;
    totalMass += comp.massGrams;
  }

  if (totalMass <= 0) return '#c8e6ff';

  const fr = Math.round(r / totalMass);
  const fg = Math.round(g / totalMass);
  const fb = Math.round(b / totalMass);

  return `#${fr.toString(16).padStart(2, '0')}${fg.toString(16).padStart(2, '0')}${fb.toString(16).padStart(2, '0')}`;
}

// ── Precipitation check (Ksp approximation) ─────────────────
export function checkPrecipitation(
  formula: string,
  concentrationMolL: number
): boolean {
  // Ksp values for common sparingly soluble salts
  const KSP: Record<string, number> = {
    AgCl: 1.77e-10,
    BaSO4: 1.08e-10,
    CaCO3: 3.36e-9,
    PbSO4: 2.53e-8,
    Fe_OH_3: 2.79e-39,
    Cu_OH_2: 2.19e-19,
  };
  const ksp = KSP[formula];
  if (!ksp) return false;
  return concentrationMolL * concentrationMolL > ksp;
}

// ── Gas state (Ideal Gas Law) ─────────────────────────────────
export function calcGasState(
  moles: number,
  volumeL: number,
  temperatureC: number
): GasState {
  const T = temperatureC + 273.15;
  const P = (moles * R_GAS * T) / volumeL / 1000; // kPa

  return {
    formula: 'mixed',
    moles,
    pressureKPa: P,
    volumeL,
    temperatureK: T,
  };
}

// ── Torricelli's Theorem pour rate ───────────────────────────
export function calcPourRate(
  liquidHeightM: number,
  orificeAreaM2: number = 0.0001 // ~1cm² default
): number {
  // v = sqrt(2 * g * h), volumetric rate = v * A (m³/s → mL/s * 1e6)
  const v = Math.sqrt(2 * G * Math.max(0, liquidHeightM));
  return v * orificeAreaM2 * 1e6; // mL/s
}

// ── Main Reaction Solver ──────────────────────────────────────
export function solveReaction(
  container: ContainerState
): StoichiometryResult {
  const reaction = findReaction(container.contents);

  if (!reaction) {
    return {
      canReact: false,
      productsFormed: [],
      reactantsConsumed: [],
      deltaHTotal: 0,
      temperatureChange: 0,
      reason: 'No known reaction for current mixture.',
    };
  }

  // Temperature gate
  const minTemp = reaction.conditions.minTemperature ?? -Infinity;
  if (container.temperatureC < minTemp) {
    return {
      canReact: false,
      productsFormed: [],
      reactantsConsumed: [],
      deltaHTotal: 0,
      temperatureChange: 0,
      reason: `Requires temperature ≥ ${minTemp}°C. Current: ${container.temperatureC.toFixed(1)}°C`,
    };
  }

  // Catalyst check
  if (reaction.conditions.catalyst) {
    const hascat = container.contents.some(
      c => c.formula === reaction.conditions.catalyst
    );
    if (!hascat) {
      return {
        canReact: false,
        productsFormed: [],
        reactantsConsumed: [],
        deltaHTotal: 0,
        temperatureChange: 0,
        reason: `Requires catalyst: ${reaction.conditions.catalyst}`,
      };
    }
  }

  // Find limiting reagent
  const limiting = findLimitingReagent(container.contents, reaction);
  if (!limiting) {
    return {
      canReact: false,
      productsFormed: [],
      reactantsConsumed: [],
      deltaHTotal: 0,
      temperatureChange: 0,
      reason: 'Insufficient reactants.',
    };
  }

  const { limitingMoles } = limiting;

  // Calc reactants consumed
  const reactantsConsumed: MixtureComponent[] = reaction.reactants.map(r => ({
    formula: r.formula,
    massGrams: getMassFromMoles(limitingMoles * r.coefficient, r.formula),
    state: 'aqueous',
  }));

  // Calc products formed
  const productsFormed: MixtureComponent[] = reaction.products.map(p => ({
    formula: p.formula,
    massGrams: getMassFromMoles(limitingMoles * p.coefficient, p.formula),
    state: p.state,
  }));

  // Gas produced?
  const gasProduct = reaction.products.find(p => p.state === 'gas');
  const gasProduced = gasProduct
    ? { formula: gasProduct.formula, moles: limitingMoles * gasProduct.coefficient }
    : undefined;

  // Precipitate?
  const solidProduct = reaction.products.find(p => p.state === 'solid');
  const precipitateFormed = solidProduct
    ? {
        formula: solidProduct.formula,
        massGrams: getMassFromMoles(limitingMoles * solidProduct.coefficient, solidProduct.formula),
      }
    : undefined;

  // Thermodynamics
  const totalMass = container.contents.reduce((s, c) => s + c.massGrams, 0);
  const cAvg = avgSpecificHeat(container.contents);
  const deltaHTotal = reaction.deltaH * limitingMoles;
  const tempChange = calcTemperatureChange(reaction.deltaH, limitingMoles, totalMass, cAvg);

  return {
    canReact: true,
    reactionId: reaction.id,
    limitingReagent: limiting.formula,
    molesReacted: limitingMoles,
    productsFormed,
    reactantsConsumed,
    deltaHTotal,
    temperatureChange: tempChange,
    gasProduced,
    precipitateFormed,
  };
}

// ── Apply reaction result to a container ────────────────────
export function applyReactionToContainer(
  container: ContainerState,
  result: StoichiometryResult
): ContainerState {
  if (!result.canReact) return container;

  let newContents = [...container.contents];

  // Remove consumed reactants
  for (const consumed of result.reactantsConsumed) {
    const idx = newContents.findIndex(c => c.formula === consumed.formula);
    if (idx === -1) continue;
    const remaining = newContents[idx].massGrams - consumed.massGrams;
    if (remaining <= 0.001) {
      newContents.splice(idx, 1);
    } else {
      newContents[idx] = { ...newContents[idx], massGrams: remaining };
    }
  }

  // Add products (skip gas phase — tracked separately)
  for (const product of result.productsFormed) {
    if (product.state === 'gas') continue;
    const existing = newContents.findIndex(c => c.formula === product.formula);
    if (existing !== -1) {
      newContents[existing] = {
        ...newContents[existing],
        massGrams: newContents[existing].massGrams + product.massGrams,
      };
    } else {
      newContents.push(product);
    }
  }

  const newTemp = container.temperatureC + result.temperatureChange;
  const newColor = mixColors(newContents);
  const newPH = estimatePH(newContents, container.volumeML);
  const newGasMol = container.gasVolumeMol + (result.gasProduced?.moles ?? 0);

  return {
    ...container,
    contents: newContents,
    temperatureC: newTemp,
    color: newColor,
    pH: newPH,
    gasVolumeMol: newGasMol,
  };
}
