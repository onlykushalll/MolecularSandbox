// ============================================================
// THE MOLECULAR SANDBOX — Chemistry Type Definitions
// ============================================================

export type PhysicalState = 'solid' | 'liquid' | 'gas' | 'aqueous';
export type ReactionType = 'synthesis' | 'decomposition' | 'single_replacement' | 'double_replacement' | 'combustion' | 'acid_base' | 'redox' | 'precipitation' | 'complexation';

export interface GHSHazard {
  code: string;       // e.g. "H290"
  category: string;   // e.g. "Flammable"
  signal: 'Danger' | 'Warning';
  symbol: string;     // emoji or icon name
}

export interface ChemicalData {
  id: string;
  name: string;
  formula: string;
  molarMass: number;          // g/mol
  density: number;            // g/mL
  specificHeatCapacity: number; // J/(g·K)
  surfaceTension: number;     // N/m
  vaporPressure: number;      // kPa at 25°C
  boilingPoint: number;       // °C
  meltingPoint: number;       // °C
  hexColor: string;           // #RRGGBB
  stateAtSTP: PhysicalState;
  hazards: GHSHazard[];
  refractiveIndex: number;
  viscosity: number;          // mPa·s
  category: string;
  description: string;
  solubility: Record<string, number>; // solvent -> g/100mL
  isRadioactive?: boolean;
  isToxic?: boolean;
  pKa?: number;               // for acids/bases
  pKb?: number;
}

export interface ReactionReactant {
  formula: string;
  coefficient: number;
}

export interface ReactionProduct {
  formula: string;
  coefficient: number;
  state: PhysicalState;
}

export interface ReactionData {
  id: string;
  name: string;
  equation: string;           // balanced equation string
  reactants: ReactionReactant[];
  products: ReactionProduct[];
  deltaH: number;             // kJ/mol (negative = exothermic)
  activationEnergy: number;   // kJ/mol
  reactionType: ReactionType;
  isReversible: boolean;
  conditions: {
    minTemperature?: number;  // °C required
    catalyst?: string;
    requiresHeat?: boolean;
    requiresLight?: boolean;
  };
  description: string;
  safetyNotes: string;
}

export interface MixtureComponent {
  formula: string;
  massGrams: number;
  state: PhysicalState;
}

export interface ContainerState {
  id: string;
  type: 'beaker' | 'flask' | 'test_tube' | 'graduated_cylinder' | 'burette';
  capacityML: number;
  volumeML: number;           // current liquid volume
  contents: MixtureComponent[];
  temperatureC: number;
  pressureKPa: number;
  isHeating: boolean;
  isStirring: boolean;
  isClosed: boolean;          // has stopper
  isBroken: boolean;
  position: [number, number, number];
  rotation: [number, number, number];
  color: string;              // computed mixture color
  pH: number;
  gasVolumeMol: number;       // moles of gas produced
}

export interface ReactionEvent {
  id: string;
  timestamp: number;
  containerId: string;
  reactionId: string;
  reactionName: string;
  equation: string;
  limitingReagent: string;
  molesReacted: number;
  deltaHTotal: number;        // kJ released/absorbed
  temperatureChange: number;  // °C
  producedGas?: string;
  producedPrecipitate?: string;
  newTemperatureC: number;
}

export interface StoichiometryResult {
  canReact: boolean;
  reactionId?: string;
  limitingReagent?: string;
  molesReacted?: number;
  productsFormed: MixtureComponent[];
  reactantsConsumed: MixtureComponent[];
  deltaHTotal: number;
  temperatureChange: number;
  gasProduced?: { formula: string; moles: number };
  precipitateFormed?: { formula: string; massGrams: number };
  reason?: string;            // why no reaction
}

export interface GasState {
  formula: string;
  moles: number;
  pressureKPa: number;
  volumeL: number;
  temperatureK: number;
}

export interface PourStream {
  fromId: string;
  toId: string;
  flowRateMLperS: number;
  tiltAngle: number;
}

export interface JournalEntry {
  id: string;
  timestamp: number;
  type: 'reaction' | 'observation' | 'measurement' | 'safety' | 'error';
  title: string;
  body: string;
  equation?: string;
  data?: Record<string, unknown>;
}

export interface LabState {
  containers: ContainerState[];
  journal: JournalEntry[];
  pourStream: PourStream | null;
  selectedContainerId: string | null;
  hoveredContainerId: string | null;
  isPPEEquipped: boolean;
  isInsideFumeHood: boolean;
  ambientTemperatureC: number;
  activeReactions: ReactionEvent[];
  unlimitedMode: boolean;
}
