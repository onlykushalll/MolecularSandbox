// Prisma seed — run with: bun prisma/seed.ts
// Seeds DB with all chemicals and reactions from embedded data

import { PrismaClient } from '@prisma/client';
import { CHEMICALS, REACTIONS } from '../src/lib/chemistry/data';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Clear existing data
  await prisma.reactionProduct.deleteMany();
  await prisma.reactionReactant.deleteMany();
  await prisma.reaction.deleteMany();
  await prisma.chemical.deleteMany();

  // Seed chemicals
  for (const chem of CHEMICALS) {
    await prisma.chemical.create({
      data: {
        id: chem.id,
        name: chem.name,
        formula: chem.formula,
        molarMass: chem.molarMass,
        density: chem.density,
        specificHeatCapacity: chem.specificHeatCapacity,
        surfaceTension: chem.surfaceTension,
        vaporPressure: chem.vaporPressure,
        boilingPoint: chem.boilingPoint,
        meltingPoint: chem.meltingPoint,
        hexColor: chem.hexColor,
        stateAtSTP: chem.stateAtSTP,
        hazards: JSON.stringify(chem.hazards),
        refractiveIndex: chem.refractiveIndex,
        viscosity: chem.viscosity,
        category: chem.category,
        description: chem.description,
        solubility: JSON.stringify(chem.solubility),
        pKa: chem.pKa ?? null,
        pKb: chem.pKb ?? null,
        isToxic: chem.isToxic ?? false,
        isRadioactive: chem.isRadioactive ?? false,
      },
    });
  }

  console.log(`✅ Seeded ${CHEMICALS.length} chemicals`);

  // Seed reactions (simplified — reactants reference chemicals by formula, map to DB IDs)
  for (const rxn of REACTIONS) {
    const created = await prisma.reaction.create({
      data: {
        id: rxn.id,
        name: rxn.name,
        equation: rxn.equation,
        deltaH: rxn.deltaH,
        activationEnergy: rxn.activationEnergy,
        reactionType: rxn.reactionType,
        isReversible: rxn.isReversible,
        conditions: JSON.stringify(rxn.conditions),
        description: rxn.description,
        safetyNotes: rxn.safetyNotes,
      },
    });
  }

  console.log(`✅ Seeded ${REACTIONS.length} reactions`);
  console.log('🎉 Database ready!');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
