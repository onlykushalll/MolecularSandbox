# 🧪 The Molecular Sandbox — Setup Guide

## Quick Start

```bash
# 1. Install dependencies (includes Three.js + R3F)
bun install

# 2. Setup database
bun db:push
bun db:generate

# 3. Start the dev server
bun dev
```

Open http://localhost:3000 (or via Caddy on port 81)

---

## First Run Checklist

- [ ] Install deps: `bun install`
- [ ] Push DB schema: `bun db:push`
- [ ] Generate Prisma client: `bun db:generate`
- [ ] Start server: `bun dev`

---

## Key Dependencies

| Package | Purpose |
|---------|---------|
| `three` | Core 3D engine |
| `@react-three/fiber` | React renderer for Three.js |
| `@react-three/drei` | Helpers (Html, Float, Environment, etc.) |
| `@react-three/rapier` | Physics engine |
| `zustand` | State management |
| `framer-motion` | UI animations |

---

## Architecture

```
src/
├── lib/
│   ├── chemistry/
│   │   ├── types.ts      ← All TypeScript interfaces
│   │   ├── data.ts       ← 35 chemicals + 20 reactions
│   │   └── engine.ts     ← Stoichiometry engine
│   └── store/
│       └── lab-store.ts  ← Zustand state
├── components/lab/
│   ├── LabScene.tsx      ← Main R3F canvas
│   ├── Beaker.tsx        ← 3D glass beaker
│   ├── LiquidMaterial.ts ← Custom GLSL liquid shader
│   ├── GlassMaterial.ts  ← Custom GLSL glass shader
│   ├── PourStream.tsx    ← Torricelli pour stream
│   ├── ChemicalPanel.tsx ← Chemical library sidebar
│   ├── InstrumentPanel.tsx ← pH/temp/pressure gauges
│   ├── LabJournal.tsx    ← Auto-logging journal
│   ├── SafetyPanel.tsx   ← PPE + GHS hazards
│   ├── Toolbar.tsx       ← Tool mode switcher
│   └── ReactionAlert.tsx ← Toast notifications
└── app/
    ├── page.tsx          ← Main lab page
    └── api/
        ├── chemicals/    ← GET chemicals
        ├── reactions/    ← GET/POST reactions
        └── simulate/     ← POST run simulation
```

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| S | Select tool |
| P | Pour tool |
| H | Heat tool |
| J | Toggle Journal |
| C | Toggle Chemicals panel |
| I | Toggle Instruments |
| X | Toggle Safety panel |
| F | Toggle heat on selected beaker |
| Esc | Deselect |

---

## Chemistry Engine

### Supported Reactions (20+)

- **Acid-Base**: HCl + NaOH, H₂SO₄ + NaOH, HCl + NH₃
- **Metal + Acid**: Zn + HCl, Mg + HCl, Na + H₂O (violent!)
- **Decomposition**: H₂O₂ → H₂O + O₂ (needs MnO₂ catalyst)
- **Precipitation**: AgNO₃ + NaCl → AgCl↓, BaCl₂ + H₂SO₄ → BaSO₄↓
- **Acid + Carbonate**: HCl + CaCO₃ → CO₂↑, HCl + Na₂CO₃ → CO₂↑
- **Combustion**: H₂ + O₂ → H₂O (explosive!)
- **Redox**: KMnO₄ + H₂O₂ → O₂↑ (decolourisation)

### Physics

- **Moles**: n = m/M
- **Temperature**: ΔT = -ΔH·n / (m·c)
- **pH**: Accurate for strong/weak acids + bases
- **Beer-Lambert**: Liquid color by concentration
- **Torricelli**: Pour rate v = √(2gh)
- **Ideal Gas Law**: PV = nRT for closed containers

---

## Visual Features

- **Custom GLSL Shaders**: Physically-based liquid with Beer-Lambert absorption, meniscus curve, wobble inertia, Fresnel highlights
- **Glass Shader**: Borosilicate glass with Fresnel, condensation via Voronoi noise, crack patterns
- **Diegetic HUD**: Holographic labels floating on beakers (formula, temperature, pH, volume)
- **Gas Particles**: Instanced mesh particles rising from containers
- **Pour Stream**: Parabolic arc with sine-wave breakup (Torricelli)
- **Heat Glow**: Point light emanating from heated containers

---

## Environment

- Hosted on Z.ai platform
- Caddy reverse proxy on port 81
- Next.js dev server on port 3000
- SQLite database at `db/custom.db`
